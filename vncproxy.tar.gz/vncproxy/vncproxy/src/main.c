/* VNC Proxy */
/* VNC Reflector
 * Copyright (C) 2001-2003 HorizonLive.com, Inc.  All rights reserved.
 *
 * This software is released under the terms specified in the file LICENSE,
 * included.  HorizonLive provides e-Learning and collaborative synchronous
 * presentation solutions in a totally Web-based environment.  For more
 * information about HorizonLive, please see our website at
 * http://www.horizonlive.com.
 *
 * This software was authored by Constantin Kaplinsky <const@ce.cctpu.edu.ru>
 * and sponsored by HorizonLive.com, Inc.
 *
 * $Id: main.c,v 1.24 2007/06/21 20:18:08 brianp Exp $
 * Main module
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <zlib.h>

#include "rfblib.h"
#include "async_io.h"
#include "logging.h"
#include "reflector.h"
#include "host_connect.h"
#include "translate.h"
#include "host_io.h"
#include "client_io.h"
#include "encode.h"
#include "http.h"
#include "options.h"

#ifdef NETLOGGER
#include "nl_log.h"
#endif


/*
 * Global variables
 */

RFB_SCREEN_INFO g_screen_info;  /* describes the remote desktop */

/* Describes our framebuffer's current size/address */
CARD32 *g_framebuffer;
CARD16 g_fb_width, g_fb_height;
int g_connected_to_dmx = 0;


/*
 * Functions local to this file
 */

static void parse_args(int argc, char **argv);
static void report_usage(char *program_name);
static int read_password_file(void);
static int init_screen_info(void);
static int write_pid_file(void);
static int remove_pid_file(void);

/*
 * Implementation
 */

int main(int argc, char **argv)
{
  long cache_hits, cache_misses;

  /* Parse command line, exit on error */
  parse_args(argc, argv);

  if (!opt.no_banner) {
    fprintf(stderr,
"VNC Proxy - Copyright (C) 2004 Tungsten Graphics, Inc., based upon:\n"
"VNC Reflector %s.  Copyright (C) 2001-2003 HorizonLive.com, Inc.\n\n"
"HorizonLive provides e-Learning and collaborative synchronous presentation\n"
"solutions in a totally Web-based environment.  For more information about\n"
"HorizonLive, please see our website at http://www.horizonlive.com/\n\n",
            VERSION);
  }

  if (!log_open(opt.log_filename, opt.file_loglevel,
                (opt.foreground) ? opt.stderr_loglevel : -1)) {
    fprintf(stderr, "%s: error opening log file (ignoring this error)\n",
            argv[0]);
  }

  log_write(LL_MSG, "Starting VNC Proxy (VNC Reflector %s)", VERSION);

  if (opt.host && opt.host_info_file) {
    log_write(LL_ERROR, "Both -H and a server/host name were specified. "
              "Only one or the other should be used.");
    exit(1);
  }

  /* Fork the process to the background if necessary */
  if (!opt.foreground) {
    if (!opt.no_banner) {
      fprintf(stderr, "Starting in the background, "
              "see the log file for errors and other messages.\n");
    }

    if (getpid() != 1) {
      signal(SIGTTIN, SIG_IGN);
      signal(SIGTTOU, SIG_IGN);
      signal(SIGTSTP, SIG_IGN);
      if (fork ())
        return 0;
      setsid();
    }
    close(0);
    close(1);
    close(2);
    log_write(LL_INFO, "Switched to the background mode");
  }

  if (opt.java_path)
    http_java_path(opt.java_path);

#ifdef NETLOGGER
  NL_logger_module("vncproxy", /* module name */
                   NULL, /* destination URL (use NL_DEST env var) */
                   NL_LVL_DEBUG, /* logging level */
                   NL_TYPE_APP, /* target type */
                   "" /* terminator */
                   );
  NL_info("vncproxy", "proxy.program.begin", "");
#endif

  /* Initialization */
  if (init_screen_info()) {
    read_password_file();
    set_host_encodings(opt.pref_encoding, opt.tight_level);
    set_client_passwords(opt.client_password, opt.client_ro_password);
    fbs_set_prefix(opt.fbs_prefix, opt.join_sessions);

    set_active_file(opt.active_filename);
    set_actions_file(opt.actions_filename);

    aio_init();
    if (opt.bind_ip != NULL) {
      if (aio_set_bind_address(opt.bind_ip)) {
        log_write(LL_INFO, "Would bind listening sockets to address %s",
                  opt.bind_ip);
      } else {
        log_write(LL_WARN, "Illegal address to bind listening sockets to: %s",
                  opt.bind_ip);
      }
    }

    set_client_listen_port(opt.cl_listen_port);

    /* print useful status info */
    printf("vncproxy: listening to port %d (display :%d) for connections.\n",
           opt.cl_listen_port, opt.cl_listen_port-5900);
    printf("vncproxy: frame sync (-F): %d\n", opt.frame_sync);
    printf("vncproxy: write coalescing (-W): %d\n", opt.write_coalescing);
    printf("vncproxy: rfb caching (-R): %d\n", opt.rfb_caching);
    printf("vncproxy: resolution scale: %d\n", opt.res_scale);

    /* and connect to servers specified in -H host file */
    if (opt.host_info_file) {
       if (!connect_to_host_by_file(opt.host_info_file)) {
          return 0; /* XXX clean up */
       }
    }
    else {
       /* connect to the server specified on command line*/
       if (!connect_to_display(opt.host, 0, 0)) {
          log_write(LL_ERROR, "Unable to connect to %s", opt.host);
          return 0; /* XXX clean up */
       }
    }

    /* Main work */
    if (write_pid_file()) {
      set_control_signals();
      aio_mainloop();
      remove_pid_file();
    }

    /* Cleanup */
    if (g_framebuffer != NULL) {
      log_write(LL_DETAIL, "Freeing framebuffer and associated structures");
      free(g_framebuffer);
      free_enc_cache();
    }
    if (g_screen_info.name != NULL)
      free(g_screen_info.name);

    get_hextile_caching_stats(&cache_hits, &cache_misses);
    if (cache_hits + cache_misses != 0) {
      log_write(LL_INFO, "Hextile BGR233 caching efficiency: %d%%",
                (int)((cache_hits * 100 + (cache_hits + cache_misses) / 2)
                      / (cache_hits + cache_misses)));
    }
  }

  log_write(LL_MSG, "Terminating");

  /* Close logs */
  if (!log_close() && opt.foreground) {
    fprintf(stderr, "%s: error closing log file (ignoring this error)\n",
            argv[0]);
  }

#ifdef NETLOGGER
  NL_info("vncproxy", "proxy.program.end", "");
  NL_logger_del();
#endif

  /* Done */
  exit(1);
}

static void parse_args(int argc, char **argv)
{
  int err = 0;
  int c;
  char *temp_pid_file = NULL;
  char temp_buf[32];            /* 32 bytes should be more than enough */

  init_options(&opt);

  while (!err &&
         (c = getopt(argc, argv, "CDhqjfFWRv:xr24p:a:c:g:l:i:s:b:tT:Q:H:d:J:S:")) != -1) {
    switch (c) {
    case 'C':
      /* XXX remove this clause someday */
      break;
    case 'H':
      opt.host_info_file = optarg;
      break;
    case 'd':
      opt.stderr_loglevel = atoi(optarg);
      if (opt.stderr_loglevel < 1)
         opt.stderr_loglevel = 1; /* so errors are always reported */
      break;
    case 'D':
      opt.force_tight_jpeg = 1;
      break;
    case 'h':
      err = 1;
      break;
    case 'q':
      opt.no_banner = 1;
      break;
    case 'j':
      opt.join_sessions = 1;
      break;
    case 'J':
      opt.java_path = optarg;
      break;
    case 'v':
      if (opt.file_loglevel != -1)
        err = 1;
      else
        opt.file_loglevel = atoi(optarg);
      break;
    case 'f':
      opt.foreground = 1;
      break;
    case 'F':
      opt.frame_sync = 1;
      break;
    case 'S':
      opt.res_scale = atoi(optarg);
      break;
    case 'W':
       opt.write_coalescing = 1;
       break;
    case 'R':
       opt.rfb_caching = 1;
       break;
    case 'p':
      if (opt.passwd_filename != NULL)
        err = 1;
      else
        opt.passwd_filename = optarg;
      break;
    case 'g':
      if (opt.log_filename != NULL)
        err = 1;
      else
        opt.log_filename = optarg;
      break;
    case 'a':
      if (opt.active_filename != NULL)
        err = 1;
      else
        opt.active_filename = optarg;
      break;
    case 'c':
      if (opt.actions_filename != NULL)
        err = 1;
      else
        opt.actions_filename = optarg;
      break;
    case 'l':
      if (opt.cl_listen_port != -1)
        err = 1;
      else {
        opt.cl_listen_port = atoi(optarg);
        if (opt.cl_listen_port <= 0)
          err = 1;
      }
      break;
    case 'i':
      if (temp_pid_file != NULL)
        err = 1;
      else
        temp_pid_file = optarg;
      break;
    case 's':
      if (opt.fbs_prefix != NULL)
        err = 1;
      else
        opt.fbs_prefix = optarg;
      break;
    case 'b':
      if (opt.bind_ip != NULL)
        err = 1;
      else
        opt.bind_ip = optarg;
      break;
    case 't':
      opt.pref_encoding = RFB_ENCODING_TIGHT;
      break;
    case 'x':
      opt.pref_encoding = RFB_ENCODING_HEXTILE;
      break;
    case 'r':
      opt.pref_encoding = RFB_ENCODING_RAW;
      break;
    case '2':
      opt.half_raw = 1;
      break;
    case '4':
      opt.pref_encoding = RFB_ENCODING_RAW24;
      break;
    case 'T':
      opt.pref_encoding = RFB_ENCODING_TIGHT;
      opt.tight_level = atoi(optarg);
      if (opt.tight_level <= 0 || opt.tight_level > 9)
        err = 1;
      break;
    case 'Q':
      opt.jpeg_quality = atoi(optarg);
      if (opt.jpeg_quality <= 0 || opt.jpeg_quality > 9)
        err = 1;
      break;
    default:
      err = 1;
    }
  }

  /* Print usage help on error */
  if (err || (optind == argc && !opt.host_info_file)) {
    report_usage(argv[0]);
    exit(1);
  }

  /* get name of server to connect to */
  if (argv[optind]) {
     opt.host = strdup(argv[optind]);
  }

  /* Provide reasonable defaults for some options */
  if (opt.file_loglevel == -1)
    opt.file_loglevel = LL_INFO;
  if (opt.passwd_filename == NULL)
    opt.passwd_filename = "passwd";
  if (opt.log_filename == NULL)
    opt.log_filename = "reflector.log";
  if (opt.cl_listen_port == -1)
    opt.cl_listen_port = 5999;

  if (opt.force_tight_jpeg) {
    log_write(0, "Forcing JPEG for tight-encoded clients");
    fprintf(stderr, "Forcing JPEG for tight-encoded clients\n");
  }

  /* Append listening port number to pid filename */
  if (temp_pid_file != NULL) {
    sprintf(temp_buf, "%d", opt.cl_listen_port);
    sprintf(opt.pid_file, "%.*s.%s", (int)(255 - strlen(temp_buf) - 1),
            temp_pid_file, temp_buf);
  }
}

static void report_usage(char *program_name)
{
  fprintf(stderr,
          "VNC Proxy -  Copyright (C) 2004 Tungsten Graphics, Inc.\n"
          "Based on VNC Reflector %s. Copyright (C) 2001-2003 HorizonLive.com, Inc.\n",
          VERSION);
  fprintf(stderr, "Usage: %s [OPTIONS...] SERVER\n",
          program_name);
  fprintf(stderr,
          "Encoding options:\n"
          "  -r              - request Raw encoding from the VNC servers (the default)\n"
          "  -x              - request Hextile encoding from the VNC servers\n"
          "  -t              - request Tight encoding from the VNC servers\n"
          "  -T COMP_LEVEL   - like -t, but use the specified compression level (1..9)\n");
  fprintf(stderr,
          "                    default = -1 (VNC server decides compression level)\n");
  fprintf(stderr,
          "  -Q QUALITY      - specifies the jpeg quality level when using tight encoding.\n");
  fprintf(stderr,
          "                    default = -1 (no jpeg encoding)\n");
  fprintf(stderr,
          "  -D              - force tight encoder to always use JPEG encoding\n");
  fprintf(stderr,
          "  -S k            - set desktop scaling factor to 1/k for all clients\n");
  fprintf(stderr,
          "Optimization options:\n"
          "  -W              - enable write coalescing\n"
          "  -R              - enable RFB caching\n");
  fprintf(stderr,
          "Synchronization options:\n"
          "  -F              - enable frame synchronization\n");
  fprintf(stderr,
          "Debug options:\n"
          "  -d LEVEL        - specify debug/info level [1 to 6]\n"
          "  -g LOG_FILE     - write logs to the specified file [default: reflector.log]\n"
          "  -v LOG_LEVEL    - set verbosity level for the log file (0..%d) [default: %d]\n",
          LL_DEBUG, LL_INFO);
  fprintf(stderr,
          "Other options:\n"
          "  -l LISTEN_PORT  - port to listen for client connections [default: 5999]\n"
          "  -J path         - specify path for Java class files for Java VNC viewer\n"
          "  -H HOSTS_FILE   - connect to servers listed in named file\n"
          "  -i PID_FILE     - write pid file, appending listening port to the filename\n"
          "  -p PASSWD_FILE  - read a plaintext client password file [default: passwd]\n"
          "  -a ACTIVE_FILE  - create file during times when a host is connected\n");
  fprintf(stderr,
          "  -c ACTIONS_FILE - on events, execute commands specified in a file\n"
          "  -b IP_ADDRESS   - bind listening sockets to a specific IP [default: any]\n"
          "  -s FBS_PREFIX   - save host sessions in rfbproxy-compatible files\n"
          "                    (optionally appending 3-digit session IDs to the\n"
          "                    filename prefix, only if used without the -j option)\n");
  fprintf(stderr,
          "  -j              - join saved sessions (see -s option) in one session file\n"
          "  -f              - run in foreground\n"
          "  -q              - suppress printing copyright banner at startup\n"
          "  -h              - print this help message\n\n");
  fprintf(stderr,
          "Please refer to the README file for a description of the file formats for\n"
          "HOST_INFO_FILE and PASSWD_FILE files mentioned above in this help text.\n\n");
}

static int read_password_file(void)
{
  FILE *passwd_fp;
  unsigned char *password_ptr = opt.client_password;
  int line = 0, len = 0;
  int c;

  /* Fill passwords with zeros */
  memset(opt.client_password, 0, 9);
  memset(opt.client_ro_password, 0, 9);

  log_write(LL_DETAIL, "Looking for passwords in the file \"%s\"",
            opt.passwd_filename);

  passwd_fp = fopen(opt.passwd_filename, "r");
  if (passwd_fp == NULL) {
    log_write(LL_WARN,
              "No password file for clients/viewers, assuming no authentication");
    return 1;
  }

  /* Read password file */
  while (line < 2) {
    c = getc(passwd_fp);
    if (c == '\r')
      c = getc(passwd_fp);      /* Handle MS-DOS-style end of line */
    if (c != '\n' && c != EOF && len < 8) {
      password_ptr[len++] = c;
    } else {
      password_ptr[len] = '\0';
      /* Truncate long passwords */
      if (len == 8 && c != '\n' && c != EOF) {
        log_write(LL_WARN, "Using only 8 first bytes of a longer password");
        do {
          c = getc(passwd_fp);
        } while (c != '\n' && c != EOF);
      }
      /* End of file */
      if (c == EOF)
        break;
      /* Empty password means no authentication */
      if (len == 0) {
        log_write(LL_WARN, "Got empty client password, hoping no auth is ok");
      }
      /* End of line */
      if (++line == 1) {
        password_ptr = opt.client_ro_password;
      }
      len = 0;
    }
  }
  if (len == 0) {
    if (line == 0) {
      log_write(LL_WARN, "Client password not specified, assuming no auth");
    } else {
      line--;
    }
  }

  log_write(LL_DEBUG, "Got %d password(s) from file, including empty ones",
            line + 1);

  /* Provide reasonable defaults if not all two passwords set */
  if (line == 0) {
    log_write(LL_DETAIL, "Read-only client password not specified");
    strcpy((char *)opt.client_ro_password, (char *)opt.client_password);
  }

  fclose(passwd_fp);
  return 1;
}

static int init_screen_info(void)
{
  union _LITTLE_ENDIAN {
    CARD32 value32;
    CARD8 test;
  } little_endian;

  /* Set the initial desktop name */
  g_screen_info.name_length = 0;
  g_screen_info.name = NULL;

  /* Fill in the PIXEL_FORMAT structure */
  g_screen_info.pixformat.bits_pixel = 32;
  g_screen_info.pixformat.color_depth = 24;
  g_screen_info.pixformat.true_color = 1;
  g_screen_info.pixformat.r_max = 255;
  g_screen_info.pixformat.g_max = 255;
  g_screen_info.pixformat.b_max = 255;
  g_screen_info.pixformat.r_shift = 16;
  g_screen_info.pixformat.g_shift = 8;
  g_screen_info.pixformat.b_shift = 0;

  /* Set correct endian flag in PIXEL_FORMAT */
  little_endian.value32 = 1;
  if (little_endian.test) {
    log_write(LL_DEBUG, "Our machine is little endian");
    g_screen_info.pixformat.big_endian = 0;
  } else {
    log_write(LL_DEBUG, "Our machine is big endian");
    g_screen_info.pixformat.big_endian = 1;
  }

  /* Make sure we would not try to free the framebuffer */
  g_framebuffer = NULL;

  return 1;
}

static int write_pid_file(void)
{
  int pid_fd, len;
  char buf[32];                 /* 32 bytes should be more than enough */

  if (opt.pid_file[0] == '\0')
    return 1;

  pid_fd = open(opt.pid_file, O_WRONLY | O_CREAT | O_EXCL, 0644);
  if (pid_fd == -1) {
    log_write(LL_ERROR, "Pid file exists, another instance may be running");
    return 0;
  }
  sprintf(buf, "%d\n", (int)getpid());
  len = strlen(buf);
  if (write(pid_fd, buf, len) != len) {
    close(pid_fd);
    log_write(LL_ERROR, "Error writing to pid file");
    return 0;
  }

  log_write(LL_DEBUG, "Wrote pid file: %s", opt.pid_file);

  close(pid_fd);
  return 1;
}

static int remove_pid_file(void)
{
  if (opt.pid_file[0] != '\0') {
    if (unlink(opt.pid_file) == 0) {
      log_write(LL_DEBUG, "Removed pid file", opt.pid_file);
    } else {
      log_write(LL_WARN, "Error removing pid file: %s", opt.pid_file);
      return 0;
    }
  }
  return 1;
}

