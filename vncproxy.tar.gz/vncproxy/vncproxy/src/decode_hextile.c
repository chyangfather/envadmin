/* VNC Reflector
 * Copyright (C) 2001-2003 HorizonLive.com, Inc.  All rights reserved.
 *
 * This software is released under the terms specified in the file LICENSE,
 * included.  HorizonLive provides e-Learning and collaborative synchronous
 * presentation solutions in a totally Web-based environment.  For more
 * information about HorizonLive, please see our website at
 * http://www.horizonlive.com.
 *
 * This software was authored by Constantin Kaplinsky <const@ce.cctpu.edu.ru>
 * and sponsored by HorizonLive.com, Inc.
 *
 * $Id: decode_hextile.c,v 1.2 2006/11/02 19:36:07 alanh Exp $
 * Decoding Hextile-encoded rectangles.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <zlib.h>

#include "rfblib.h"
#include "reflector.h"
#include "async_io.h"
#include "logging.h"
#include "host_io.h"

typedef struct
{
  CARD8 subenc;
  CARD8 num_subrects;
  CARD32 bg, fg;
  FB_RECT rect, tile;
/* FIXME: Evil/buggy servers can overflow this buffer */
  CARD32 hextile_buf[256 + 2];
} HextileInfo;


static void rf_host_hextile_subenc(void);
static void rf_host_hextile_raw(void);
static void rf_host_hextile_hex(void);
static void rf_host_hextile_subrects(void);

static void hextile_fill_subrect(CARD8 pos, CARD8 dim);
static void hextile_next_tile(void);

static HextileInfo *
get_hextile_info(AIO_SLOT *s)
{
   return (HextileInfo *) s->encoder_private;
}

void setread_decode_hextile(FB_RECT *r)
{
  HextileInfo *h = get_hextile_info(cur_slot);

  h->rect = *r;

  h->tile.x = h->rect.x;
  h->tile.y = h->rect.y;
  h->tile.w = (h->rect.w < 16) ? h->rect.w : 16;
  h->tile.h = (h->rect.h < 16) ? h->rect.h : 16;
  aio_setread(rf_host_hextile_subenc, NULL, sizeof(CARD8));
}

static void rf_host_hextile_subenc(void)
{
  HextileInfo *h = get_hextile_info(cur_slot);
  int data_size;

  /* Copy data for saving in a file if necessary */
  fbs_spool_byte(cur_slot->readbuf[0]);

  h->subenc = cur_slot->readbuf[0];
  if (h->subenc & RFB_HEXTILE_RAW) {
    data_size = h->tile.w * h->tile.h * sizeof(CARD32);
    aio_setread(rf_host_hextile_raw, h->hextile_buf, data_size);
    return;
  }
  data_size = 0;
  if (h->subenc & RFB_HEXTILE_BG_SPECIFIED) {
    data_size += sizeof(CARD32);
  } else {
    fill_fb_rect(&h->tile, h->bg);
  }
  if (h->subenc & RFB_HEXTILE_FG_SPECIFIED)
    data_size += sizeof(CARD32);
  if (h->subenc & RFB_HEXTILE_ANY_SUBRECTS)
    data_size += sizeof(CARD8);
  if (data_size) {
    aio_setread(rf_host_hextile_hex, h->hextile_buf, data_size);
  } else {
    hextile_next_tile();
  }
}

static void rf_host_hextile_raw(void)
{
  HextileInfo *h = get_hextile_info(cur_slot);
  int row;
  CARD32 *from_ptr;
  CARD32 *fb_ptr;

  fbs_spool_data(h->hextile_buf, h->tile.w * h->tile.h * sizeof(CARD32));

  from_ptr = h->hextile_buf;
  fb_ptr = &g_framebuffer[h->tile.y * (int)g_fb_width + h->tile.x];

  /* Just copy raw data into the framebuffer */
  for (row = 0; row < h->tile.h; row++) {
    memcpy(fb_ptr, from_ptr, h->tile.w * sizeof(CARD32));
    from_ptr += h->tile.w;
    fb_ptr += g_fb_width;
  }

  hextile_next_tile();
}

static void rf_host_hextile_hex(void)
{
  HextileInfo *h = get_hextile_info(cur_slot);
  CARD32 *from_ptr = h->hextile_buf;
  int data_size;

  /* Get background and foreground colors */
  if (h->subenc & RFB_HEXTILE_BG_SPECIFIED) {
    h->bg = *from_ptr++;
    fill_fb_rect(&h->tile, h->bg);
  }
  if (h->subenc & RFB_HEXTILE_FG_SPECIFIED) {
    h->fg = *from_ptr++;
  }

  if (h->subenc & RFB_HEXTILE_ANY_SUBRECTS) {
    fbs_spool_data(h->hextile_buf, (from_ptr - h->hextile_buf) * sizeof(CARD32) + 1);
    h->num_subrects = *((CARD8 *)from_ptr);
    if (h->subenc & RFB_HEXTILE_SUBRECTS_COLOURED) {
      data_size = 6 * (unsigned int)h->num_subrects;
    } else {
      data_size = 2 * (unsigned int)h->num_subrects;
    }
    if (data_size > 0) {
      aio_setread(rf_host_hextile_subrects, NULL, data_size);
      return;
    }
  } else {
    fbs_spool_data(h->hextile_buf, (from_ptr - h->hextile_buf) * sizeof(CARD32));
  }

  hextile_next_tile();
}

/* FIXME: Not as efficient as it could be. */
static void rf_host_hextile_subrects(void)
{
  HextileInfo *h = get_hextile_info(cur_slot);
  CARD8 *ptr;
  CARD8 pos, dim;
  int i;

  ptr = cur_slot->readbuf;

  if (h->subenc & RFB_HEXTILE_SUBRECTS_COLOURED) {
    fbs_spool_data(ptr, h->num_subrects * 6);
    for (i = 0; i < (int)h->num_subrects; i++) {
      memcpy(&h->fg, ptr, sizeof(h->fg));
      ptr += sizeof(h->fg);
      pos = *ptr++;
      dim = *ptr++;
      hextile_fill_subrect(pos, dim);
    }
  } else {
    fbs_spool_data(ptr, h->num_subrects * 2);
    for (i = 0; i < (int)h->num_subrects; i++) {
      pos = *ptr++;
      dim = *ptr++;
      hextile_fill_subrect(pos, dim);
    }
  }

  hextile_next_tile();
}

/********************/
/* Helper functions */
/********************/

static void hextile_fill_subrect(CARD8 pos, CARD8 dim)
{
  HextileInfo *h = get_hextile_info(cur_slot);
  int pos_x, pos_y, dim_w, dim_h;
  int x, y, skip;
  CARD32 *fb_ptr;

  pos_x = pos >> 4 & 0x0F;
  pos_y = pos & 0x0F;
  fb_ptr = &g_framebuffer[(h->tile.y + pos_y) * (int)g_fb_width +
                          (h->tile.x + pos_x)];

  /* Optimization for 1x1 subrects */
  if (dim == 0) {
    *fb_ptr = h->fg;
    return;
  }

  /* Actually, we should add 1 to both dim_h and dim_w. */
  dim_w = dim >> 4 & 0x0F;
  dim_h = dim & 0x0F;
  skip = g_fb_width - (dim_w + 1);

  for (y = 0; y <= dim_h; y++) {
    for (x = 0; x <= dim_w; x++) {
      *fb_ptr++ = h->fg;
    }
    fb_ptr += skip;
  }
}

static void hextile_next_tile(void)
{
  HextileInfo *h = get_hextile_info(cur_slot);
  if (h->tile.x + 16 < h->rect.x + h->rect.w) {
    /* Next tile in the same row */
    h->tile.x += 16;
    if (h->tile.x + 16 < h->rect.x + h->rect.w)
      h->tile.w = 16;
    else
      h->tile.w = h->rect.x + h->rect.w - h->tile.x;
  } else if (h->tile.y + 16 < h->rect.y + h->rect.h) {
    /* First tile in the next row */
    h->tile.x = h->rect.x;
    h->tile.w = (h->rect.w < 16) ? h->rect.w : 16;
    h->tile.y += 16;
    if (h->tile.y + 16 < h->rect.y + h->rect.h)
      h->tile.h = 16;
    else
      h->tile.h = h->rect.y + h->rect.h - h->tile.y;
  } else {
    fbupdate_rect_done();       /* No more tiles */
    return;
  }
  aio_setread(rf_host_hextile_subenc, NULL, 1);
}

