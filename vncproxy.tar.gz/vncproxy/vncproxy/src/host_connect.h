/* VNC Reflector
 * Copyright (C) 2001-2003 HorizonLive.com, Inc.  All rights reserved.
 *
 * This software is released under the terms specified in the file LICENSE,
 * included.  HorizonLive provides e-Learning and collaborative synchronous
 * presentation solutions in a totally Web-based environment.  For more
 * information about HorizonLive, please see our website at
 * http://www.horizonlive.com.
 *
 * This software was authored by Constantin Kaplinsky <const@ce.cctpu.edu.ru>
 * and sponsored by HorizonLive.com, Inc.
 *
 * $Id: host_connect.h,v 1.2 2007/04/21 21:11:36 brianp Exp $
 * Connecting to a VNC host
 */

#ifndef _REFLIB_HOSTCONNECT_H
#define _REFLIB_HOSTCONNECT_H

#include "host_io.h"

extern void set_host_encodings(int pref_encoding, int tight_level);
extern void set_client_listen_port(int port);
extern HOST_SLOT *connect_to_host(const char *hostname, const char *dpyname, int port, int x, int y, int is_input_only);
extern int connect_to_host_by_file(const char *host_info_file);
extern int connect_to_hosts(const char *host_info_file);
extern int connect_to_display(const char *displayName, int x, int y);

extern int get_dmx_screen_position(const char *backendHostname, int *xpos, int *ypos);
extern int get_dmx_num_screens(void);

/* FIXME: Move this stuff to another file. */
extern int alloc_framebuffer(int w, int h);

#endif /* _REFLIB_HOSTCONNECT_H */
