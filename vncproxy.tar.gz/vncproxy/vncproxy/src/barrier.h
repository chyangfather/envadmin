
#ifndef BARRIER_H
#define BARRIER_H


extern void
window_barrier(int winID, int frameNum);

extern void
cleanup_barriers(int port);


#endif /* BARRIER_H */
