/* VNC Reflector
 * Copyright (C) 2001-2003 HorizonLive.com, Inc.  All rights reserved.
 *
 * This software is released under the terms specified in the file LICENSE,
 * included.  HorizonLive provides e-Learning and collaborative synchronous
 * presentation solutions in a totally Web-based environment.  For more
 * information about HorizonLive, please see our website at
 * http://www.horizonlive.com.
 *
 * This software was authored by Constantin Kaplinsky <const@ce.cctpu.edu.ru>
 * and sponsored by HorizonLive.com, Inc.
 *
 * $Id: host_io.h,v 1.4 2007/05/16 22:02:10 brianp Exp $
 * Asynchronous interaction with VNC host.
 */

#ifndef _REFLIB_HOST_IO_H
#define _REFLIB_HOST_IO_H

#include "region.h"

#define TYPE_HOST_LISTENING_SLOT   2
#define TYPE_HOST_CONNECTING_SLOT  3
#define TYPE_HOST_ACTIVE_SLOT      4

/* Extension to AIO_SLOT structure to hold state for host connection */
typedef struct _HOST_SLOT {
  AIO_SLOT s;

  CARD32 temp_len;
  CARD16 fb_width;
  CARD16 fb_height;
  CARD32 auth_mode; /** authentication mode */

  /* new for DMX / Chromium */
  CARD16 fb_x_origin;
  CARD16 fb_y_origin;
  int is_input_only;
  int is_vnc_spu;
  int server_port;
  struct _HOST_SLOT *dmx_host; /* only set if is_vnc_spu is nonzero */

  /* used while receiving FB updates */
  CARD16 rect_count;
  FB_RECT cur_rect;
  CARD16 rect_cur_row;
  RegionRec region;   /* records the rects received during an update */

  unsigned int serial_number;
  unsigned int rcv_serial_number;
} HOST_SLOT;

extern void host_activate(void);
extern void host_close_hook(void);

extern void pass_msg_to_master_host(CARD8 *msg, size_t len);
extern void pass_cuttext_to_master_host(CARD8 *text, size_t len);

extern void fill_fb_rect(FB_RECT *r, CARD32 color);
extern void fbupdate_rect_done(void);
extern void set_master_host(HOST_SLOT *slot);
extern void request_update_rect(HOST_SLOT *hs, int incr, int x, int y, int w, int h);
extern void request_update_all(void);

/* decode_hextile.c */

extern void setread_decode_hextile(FB_RECT *r);

/* decode_tight.c */

extern void setread_decode_tight(FB_RECT *r);
extern void reset_tight_streams(void);

#endif /* _REFLIB_HOST_IO_H */
