
#ifndef OPTIONS_H
#define OPTIONS_H


struct options {
  int   no_banner;
  int   cl_listen_port;
  char *log_filename;
  char *passwd_filename;
  char *active_filename;
  char *actions_filename;
  int   foreground;
  int   stderr_loglevel;
  int   file_loglevel;
  char  pid_file[256];
  char *fbs_prefix;
  int   join_sessions;
  char *bind_ip;
  int   pref_encoding;
  int   tight_level;
  int   jpeg_quality;
  char *java_path;

  unsigned char client_password[9];
  unsigned char client_ro_password[9];

  char *host_info_file;
  char *host;

  int frame_sync;
  int write_coalescing;
  int rfb_caching;
  int force_tight_jpeg;

  int half_raw;

  int res_scale; /* resolution scale factor: 1, 2, 4, etc */
};


extern struct options opt;


extern void init_options(struct options *opt);


#endif /* OPTIONS_H */

