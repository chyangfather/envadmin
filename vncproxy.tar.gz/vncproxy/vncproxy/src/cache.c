/**
 * RFB Caching module
 * Copyright 2006 Tungsten Graphics, Inc.
 *
 * Author: Brian Paul
 */

/*
 * Normally, the VNC Proxy receives RFB update messages from the
 * RFB/VNC servers, decodes those messages and writes the data into the
 * virtual framebuffer.  When we get update requests from VNC clients,
 * we grab pixels out of the framebuffer, encode them, and send them to
 * the client.
 *
 * For a window that's animating we often wind up decoding an RFB
 * message and then re-encoding the window region and sending the data
 * to the VNC clients.
 *
 * With a cache we can avoid the expense of re-encoding those window
 * regions.  The idea is to keep a copy of the incoming, encoded RFB
 * messages in a cache then send those messages on to the VNC clients
 * whenever possible.
 *
 * This is a bit tricky, of course:
 *
 * 1. We need to keep track of the regions represented by each cached
 * message.  When a new message arrives that overlaps a cached
 * message's region, we need to discard the older message.
 *
 * 2. We need to look at the region of _all_ incoming RFB messages,
 * even if we don't plan to cache the particular message because the
 * new message may invalidate the data of a previously cached region.
 *
 * 3. We may be able to fully satisfy and RFB update request from a
 * viewer with cached data.  Other times the cache may only have some
 * of the requested region.  In that case we still need to encode/send
 * in the conventional manner those regions not satisifed by the cache.
 *
 * 4. The Tight encoding is especially difficult because of the
 * "stately" nature of zlib encoding.  The encoding of a particular
 * block is effected by the encoding of all previous blocks.  The
 * encoded blocks must all be decoded in the same order to keep the
 * encoder/decoder in sync.  Since caching can change the order in
 * which blocks are decoded, zlib will fail.  The solution is to
 * "reset" the zlib encoder/decoder for each RFB update message.
 * Luckily, there's a mechanism in the Tight protocol to accomodate
 * this.  But it requires some special code in the RFB server/encoder.
 * Only the Chromium VNC SPU has been updated to do this.  That's why
 * we test 'hs->is_vnc_spu' in this code.
 *
 * The cache should never get very large.  In fact, it should never require
 * more memory than the virtual framebuffer.  That's because the entries
 * in the cache always represent disjoint regions.  And, each encoded region
 * should require less memory than a raw region of the same size.
 *
 * The test for overlapping cache regions is the only mechanism we need to
 * keep the cache size in check.
 *
 * Also, since the cache is relatively small, we can get by with a simple
 * linked list of cache entries.
 *
 * When we send cached data to a client, we just insert the block into
 * the slot's outgoing I/O list (no copying is needed).
 */



#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "async_io.h"
#include "rfblib.h"
#include "cache.h"
#include "region.h"
#include "logging.h"
#include "options.h"
#include "reflector.h"

extern int put_rect_header(CARD8 *buf, const FB_RECT *r);

#define INITIAL_CACHE_BUFFER_SIZE 4000


typedef struct cache_entry {
   RegionRec region;
   int num_rects;

   AIO_SLOT *slot;
   AIO_BLOCK *block;    /* this is where the cached data is stored */

   int encoding;

   int recording;       /* currently caching? */
   int marked_for_send; /* set by cache_search() function */

   struct cache_entry *next;

   int numTimesSent;
} CACHE_ENTRY;


/**
 * The cache is fairly small so a linked list is OK (for now).
 */
static CACHE_ENTRY *CacheHead = NULL;


/**
 * Return number of entries in the cache.
 */
static int
cache_size(void)
{
   int count = 0;
   const CACHE_ENTRY *ent;

   for (ent = CacheHead; ent; ent = ent->next) {
      count++;
   }
   return count;
}


/**
 * Allocate/return new cache entry.
 */
static CACHE_ENTRY *
new_entry(int alloc_block)
{
   CACHE_ENTRY *ent = (CACHE_ENTRY *) calloc(1, sizeof(CACHE_ENTRY));
   if (ent && alloc_block) {
      ent->block = (AIO_BLOCK *) calloc(1, sizeof(AIO_BLOCK));
      ent->block->in_cache_flag = 1;
   }
   return ent;
}


/**
 * Remove entry from cache list, but don't delete it.
 */
static void
remove_entry(CACHE_ENTRY *delEnt)
{
   CACHE_ENTRY *ent, *prev = NULL, *next = NULL;

   for (ent = CacheHead; ent; ent = next) {
      next = ent->next;
      if (ent == delEnt) {
         /* found it */
         if (prev)
            prev->next = ent->next;
         else
            CacheHead = ent->next;
         ent->next = NULL;
         break;
      }
      else {
         prev = ent;
      }
   }
}


/**
 * Insert cache entry into cache.
 */
static void
insert_entry(CACHE_ENTRY *ent)
{
   /* insert at head */
   ent->next = CacheHead;
   CacheHead = ent;
}


/**
 * Delete a cache entry.  Should not be in cache list.
 */
static void
delete_entry(CACHE_ENTRY *ent)
{
   if (ent->block) {
      if (ent->block->in_list_flag) {
         /* currently in the list of blocks to be written (async_io.c) */
         ent->block->in_cache_flag = 0;
         free(ent);
         return;
      }

      assert(!ent->next);
      assert(ent->block->in_cache_flag);
      REGION_UNINIT(&ent->region);
      if (ent->block->data)
         free(ent->block->data);
      free(ent->block);
   }
   free(ent);
}


/**
 * Insert a cache entry into the cache.  Discard any previous entries
 * which overlap the new one.
 */
static void
add_entry(CACHE_ENTRY *newEnt)
{
   CACHE_ENTRY *ent, *next = NULL;

#if 0
   /* debug/test only: remove all prev entries */
   while ((ent = CacheHead)) {
      remove_entry(ent);
      delete_entry(ent);
   }
#endif

   /* search for intersecting regions */
   for (ent = CacheHead; ent; ent = next) {
      RegionRec intersection;
      REGION_INIT(&intersection, NullBox, 0);
      REGION_INTERSECT(&intersection, &ent->region, &newEnt->region);
      next = ent->next;
      if (REGION_NUM_RECTS(&intersection) > 0) {
         /* discard this entry */
         log_write(LL_DEBUG, "  Removing prev, overlapping region (ent %p)",
                (void*) ent);
         remove_entry(ent);
         delete_entry(ent);
      }
      REGION_UNINIT(&intersection);
   }

   if (newEnt->block) {
      /* Only really save this entry if there's associated data. */
      /* We'll get non-data entries from the XF4VNC servers.  We need to
       * watch those updates to invalidate the entries we're caching from
       * the VNC SPUs.
       */
      insert_entry(newEnt);
   }
   else {
      delete_entry(newEnt);
   }
}


/**
 * Append data to the cache entry.
 */
void
cache_data(CACHE_ENTRY *ent, const unsigned char *data, size_t bytes)
{
   AIO_BLOCK *block = ent->block;

   if (!ent->recording)
      return;

   if (block->data_size + bytes > block->buffer_size) {
      /* need to allocate more space */
      if (block->buffer_size == 0) {
         /* initial allocation */
         assert(block->data == NULL);
         assert(block->data_size == 0);
         block->buffer_size = 100*1000; /*bytes * 2;*/
         block->data = malloc(block->buffer_size);
      }
      else {
         /* grow allocation */
         while (block->data_size + bytes > block->buffer_size) {
            block->buffer_size *= 2;
         }
         block->data = realloc(block->data, block->buffer_size);
      }
   }

   assert(block->data_size + bytes <= block->buffer_size);
   memcpy(block->data + block->data_size, data, bytes);
   block->data_size += bytes;
   assert(block->data_size <= block->buffer_size);
}



/**
 * Begin caching the data written to encode the given rect.
 */
void
begin_caching(HOST_SLOT *hs)
{
   CACHE_ENTRY *ent;

   if (!opt.rfb_caching) {
     return;
   }

   assert(hs);
   assert(!hs->s.cache);

   ent = new_entry(hs->is_vnc_spu);
   assert(ent);

   log_write(LL_DEBUG, "Begin caching on slot %p (ent %p)",
             (void*) &hs->s, (void*) ent);
#if 0
   printf("Begin caching on slot %p %s  (ent %p)\n",
             (void*) &hs->s, hs->s.name, (void*) ent);
#endif

   REGION_INIT(&ent->region, NullBox, 4);

   ent->slot = &hs->s;
   hs->s.cache = ent;

   if (hs->is_vnc_spu) {
     /* We only cache RFB coming from VNC SPUs since they're modified to
      * reset the zlib encoder for every update.
      */
     ent->recording = 1;
   }
}


/**
 * Called for each rfbupdate rectangle we receive (may be many within one
 * rfb update message).
 * We'll discard/ignore some fbupdate rects depending on the encoding
 * and save others (into the cache).
 */
void
cache_rect(HOST_SLOT *hs, const FB_RECT *r)
{
   CACHE_ENTRY *ent;
   AIO_BLOCK *block;

   assert(hs);
   ent = hs->s.cache;
   if (!ent) {
      /* not caching on this slot */
      return;
   }

   block = ent->block;

   /* check if this rect is an encoding we care about */
   if (r->enc != RFB_ENCODING_RAW
       && r->enc != RFB_ENCODING_RAW24
       && r->enc != RFB_ENCODING_TIGHT
       && r->enc != RFB_ENCODING_HEXTILE
       /*&& r->enc != RFB_ENCODING_LASTRECT*/) {
      log_write(LL_DEBUG, "Cache rect enc 0x%x omit on %p",
                r->enc, (void*)&hs->s);
      if (ent->recording) {
         /* "uncache" the 12-byte header for this rect */
         assert(hs->is_vnc_spu);
         ent->recording = 0;
         assert(block->data_size >= 12);
         block->data_size -= 12;
         log_write(LL_DEBUG, "  uncache 12, data_size = %d", block->data_size);
      }
      return;
   }

   if (block) {
      if (ent->recording) {
         /* The rect header was already recorded in the cache block but it
          * may not have the DMX-biased coordinates.
          * Re-write the rect header now to ensure we have DMX-biased coords.
          */
         assert(block->data_size >= 12);
         put_rect_header(block->data + block->data_size - 12, r);
      }
      else {
         /* This rect header was not recorded in the cache block,
          * put it there now.
          */
         assert(block->data_size + 12 <= block->buffer_size);
         put_rect_header(block->data + block->data_size, r);
         block->data_size += 12;
         ent->recording = 1;
      }
      ent->encoding = r->enc;
   }

   ent->num_rects++;

   /* update the cache entry's region info */
   {
      BoxRec box;
      RegionRec boxReg;

      box.x1 = r->x;
      box.x2 = r->x + r->w;
      box.y1 = r->y;
      box.y2 = r->y + r->h;

      if (block) {
#if 0
         printf(
             "Cache rect %d, %d .. %d, %d  enc 0x%x  total bytes = %d on %p\n",
               box.x1, box.y1, box.x2, box.y2, r->enc,
               block->data_size, (void *) &hs->s);
#endif
      }
      else {
         log_write(LL_DEBUG, "Cache rect, no data");
      }

      if (box.x2 > box.x1 && box.y2 > box.y1) {
          /* ignore empty rects */
          REGION_INIT(&boxReg, &box, 1);
          REGION_UNION(&ent->region, &ent->region, &boxReg);
      }
   }
}


/**
 * Called after last rfb update rect in an rfb update message has been
 * received.
 */
void
end_caching(HOST_SLOT *hs)
{
   CACHE_ENTRY *ent;

   assert(hs);
   ent = hs->s.cache;
   if (!ent) {
      /* not caching on this slot */
      return;
   }

   assert(ent->slot == &hs->s);

   if (ent->block) {
      log_write(LL_DEBUG, "End caching on slot %p, %d bytes (ent %p)",
                (void *) &hs->s, ent->block->data_size, (void*) ent);
#if 0
      printf( "End caching on slot %p, %d bytes (ent %p) %d rects\n",
              (void *) &hs->s, ent->block->data_size, (void*) ent,
              ent->num_rects);
#endif
      /*
        miPrintRegion(&ent->region);
      */
   }
   else {
      log_write(LL_DEBUG, "End caching on slot %p, no data", (void*) &hs->s);
   }

   ent->recording = 0;
   ent->slot->cache = NULL;
   assert(hs->s.cache == NULL);

#if 0
   if (ent->block->data_size < 100) {
      /* too small, discard */
      log_write(LL_DEBUG, "  Discard entry");
      delete_entry(ent);
   }
   else
#endif
   {
      add_entry(ent);
   }
   log_write(LL_DEBUG, "  Current cache size: %d\n", cache_size());
}


#if 0
static int
miRegionsEqual(const RegionPtr r1, const RegionPtr r2)
{
  const int n1 = REGION_NUM_RECTS(r1);
  const int n2 = REGION_NUM_RECTS(r2);
  const BoxPtr p1 = REGION_RECTS(r1);
  const BoxPtr p2 = REGION_RECTS(r2);
  int i;

  if (n1 != n2)
    return 0;

  for (i = 0; i < n1; i++) {
    if (p1[i].x1 != p2[i].x1 ||
        p1[i].y1 != p2[i].y1 ||
        p1[i].x2 != p2[i].x2 ||
        p1[i].y2 != p2[i].y2) {
       return 0;
    }
  }
  return 1;
}
#endif


/**
 * Return the area of the given region.
 */
static int
miRegionArea(const RegionPtr region)
{
   const BoxPtr rects = REGION_RECTS(region);
   int area = 0, n = REGION_NUM_RECTS(region), i;

   for (i = 0; i < n; i++) {
      area += (rects[i].x2 - rects[i].x1) * (rects[i].y2 - rects[i].y1);
   }
   return area;
}



/*
 * Test if region r1 (mostly) contains region r2.
 */
static int
miRegionContainsRegion(const RegionPtr r1, const RegionPtr r2)
{
   RegionRec diff;
   int retVal;

   REGION_INIT(&diff, NullBox, 0);
   REGION_SUBTRACT(&diff, r2, r1);  /* diff = r2 - r1 */
   if (REGION_NIL(&diff)) {
      /* r1 fully contains r2 */
      retVal = 1;
   }
   else {
      /* See if intersection is "large enough".  That is, if r1 doesn't
       * fully contain r2, see if some reasonable percentage of r2
       * is inside r1.
       */
      static float threshold = -1.0;
      float ratio;
      int intersectionArea, r2Area;
      RegionRec intersection;
      if (threshold < 0.0) {
         const char *t = getenv("VNCPROXY_CACHE_PERCENT");
         if (t)
            threshold = atof(t);
         if (threshold < 0.0)
            threshold = 75.0;
         log_write(LL_MSG, "Cache intersection percentage: %g", threshold);
         threshold /= 100.0;
         assert(threshold >= 0.0);
         assert(threshold <= 1.0);
      }

      REGION_INIT(&intersection, NullBox, 0);
      REGION_INTERSECT(&intersection, r1, r2);
      intersectionArea = miRegionArea(&intersection);
      r2Area = miRegionArea(r2);
      ratio = (float) intersectionArea / (float) r2Area;
      assert(ratio <= 1.0);
      /*
      printf("intersect ratio: %f %d:%d\n", ratio, intersectionArea, r2Area);
      */
      REGION_UNINIT(&intersection);
      if (ratio >= threshold)
         retVal = 1;
      else
         retVal = 0;
   }

   REGION_UNINIT(&diff);
   return retVal;
}

static int SearchCalls = 0, SearchHits = 0, SearchBytes = 0;


/**
 * Search cache for data inside the given region.
 * Entries which fall into the given region are "marked for sending".
 * \param  the required encoding
 * \return  number of rects if cache hit, 0 if miss.
 */
/* XXX need to check client's encoding vs. cached data encoding */
int
cache_search(CL_SLOT *cl, RegionPtr remainder)
{
   int rectCount = 0, entCount = 0;
   CACHE_ENTRY *ent;
   int hitBytes = 0;
   const RegionPtr region = &cl->pending_region;
   const int encoding = cl->enc_prefer;

   if (!opt.rfb_caching)
      return 0;

   if (cl->res_scale != 1)
      return 0;

   REGION_INIT(remainder, NullBox, 0);
   REGION_COPY(remainder, region);

#if 0
   printf("Searching cache for region: %d, %d .. %d, %d\n",
          region->extents.x1, region->extents.y1, 
          region->extents.x2, region->extents.y2);
#endif

   /*
   log_write(LL_DEBUG, "Searching cache for region:");
   miPrintRegion(region);
   */

   for (ent = CacheHead; ent; ent = ent->next) {
      /*
      log_write(LL_DEBUG, "Cache entry %p:", (void*) ent);
      miPrintRegion(&ent->region);
      */
      if (ent->encoding == encoding &&
          miRegionContainsRegion(region, &ent->region) &&
          !ent->block->in_list_flag) {
         /* If block is already in an another client's output list,
          * we can't put it into this client's list (there's only one 'next'
          * pointer!).
          */
         ent->marked_for_send = 1;
         REGION_SUBTRACT(remainder, remainder, &ent->region);
         entCount++;
         rectCount += ent->num_rects;
         hitBytes += ent->block->data_size;
      }
      else {
         /* miss */
      }
   }

   log_write(LL_DEBUG, "cache_search returning %d hits, %d bytes",
             rectCount, hitBytes);

#if 0
   printf("cache_search returning %d rects, %d entries\n",
          rectCount, entCount);
#endif

   SearchCalls++;
   SearchBytes += hitBytes;
   if (rectCount)
      SearchHits++;

   if (SearchCalls == 100) {
      int avg = SearchHits ? (SearchBytes / SearchHits) : 0;
      log_write(LL_MSG, "Cache: %d hits in %d calls (%d bytes/entry)",
                SearchHits, SearchCalls, avg);
      fflush(stdout); 
      SearchCalls = 0;
      SearchHits = 0;
      SearchBytes = 0;
   }

   /*
   log_write(LL_DEBUG, "remaining region:");
   miPrintRegion(remainder);
   */
   return rectCount;
}


/**
 * Send (to cur_slot) those cache entries "marked for send".
 * Clear the "marked_for_send" flags too.
 * \return number of pixels sent
 */
/* XXX need to check client's encoding vs. cached data encoding */
int
cache_send(const RegionPtr region, const char *where, int *containsCenterPixel)
{
   int rectCount = 0, pixels = 0;
   CACHE_ENTRY *ent;

   *containsCenterPixel = 0;

   log_write(LL_DEBUG, "Cache send:");
   for (ent = CacheHead; ent; ent = ent->next) {
      if (ent->marked_for_send) {
         BoxRec box;
         const int x = g_fb_width / 2, y = g_fb_height / 2;
         if (miPointInRegion(&ent->region, x, y, &box)) {
#if 0
            fprintf(stderr,
                    "VNC Proxy: Sending RFB cached update at (%d, %d) (%s)\n",
                    x, y, where);
#endif
            *containsCenterPixel = 1;
         }
         pixels += miRegionArea(&ent->region);
         aio_write_nocopy(NULL, ent->block);
         rectCount += ent->num_rects;
         ent->marked_for_send = 0;
         ent->numTimesSent++;
         if (ent->numTimesSent > 1) {
            log_write(LL_WARN, "Sent a cached entry %d times",
                      ent->numTimesSent);
         }
      }
   }

   log_write(LL_DEBUG, "Cache send returning %d\n", rectCount);
   return pixels;  /* was rectCount */
}
