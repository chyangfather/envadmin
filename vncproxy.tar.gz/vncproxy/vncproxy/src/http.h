
#ifndef _HTTP_H
#define _HTTP_H

extern void http_init(int serverPort);
extern void http_java_path(const char *path);

#endif


