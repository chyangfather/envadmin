#ifndef SYNC_H
#define SYNC_H

struct sync_group;

extern void
sync_group_size(int size);

extern struct sync_group *
sync_add_host(HOST_SLOT *hs, int port);

extern void
sync_remove_host(HOST_SLOT *hs);

extern void
sync_remove_client(CL_SLOT *cl);

extern void
sync_begin_recv_update(HOST_SLOT *hs);

extern void
sync_end_recv_update(HOST_SLOT *hs);

extern void
sync_recv_update_request(CL_SLOT *cl);

extern int
sync_blocked(void);


#endif /* SYNC_H */

