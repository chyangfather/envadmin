/* VNC Reflector
 * Copyright (C) 2001-2003 HorizonLive.com, Inc.  All rights reserved.
 * Copyright (C) 2000,2001 Constantin Kaplinsky.  All rights reserved.
 *
 * This software is released under the terms specified in the file LICENSE,
 * included.  HorizonLive provides e-Learning and collaborative synchronous
 * presentation solutions in a totally Web-based environment.  For more
 * information about HorizonLive, please see our website at
 * http://www.horizonlive.com.
 *
 * This software was authored by Constantin Kaplinsky <const@ce.cctpu.edu.ru>
 * and sponsored by HorizonLive.com, Inc.
 *
 * $Id: decode_tight.c,v 1.2 2006/12/21 23:33:04 brianp Exp $
 * Decoding Tight-encoded rectangles.
 */

#define DECODE_JPEG 1

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <zlib.h>
#if DECODE_JPEG
#include <jpeglib.h>
#endif

#include "rfblib.h"
#include "reflector.h"
#include "async_io.h"
#include "logging.h"
#include "host_io.h"


/*
 * These fields used to be static vars.  Now they're attached to a
 * specific io slot.
 */
typedef struct {
   FB_RECT rect;
   z_stream zstream[4];
   int zstream_active[4];
   CARD8 reset_streams;

   int stream_id;
   int filter_id;
   int num_colors;
   CARD32 palette[256];
   int compressed_size, uncompressed_size;
} TightInfo;


static void rf_host_tight_compctl(void);
static void rf_host_tight_fill(void);
static void rf_host_tight_filter(void);
static void rf_host_tight_numcolors(void);
static void rf_host_tight_palette(void);
static void rf_host_tight_raw(void);
static void rf_host_tight_indexed(void);
static void rf_host_tight_len1(void);
static void rf_host_tight_len2(void);
static void rf_host_tight_len3(void);
static void rf_host_tight_compressed(void);

static void tight_draw_truecolor_data(CARD8 *src);
static void tight_draw_indexed_data(CARD8 *src);
static void tight_draw_gradient_data(CARD8 *src);



static TightInfo *
get_tight_info(AIO_SLOT *s)
{
   return (TightInfo *) s->encoder_private;
}



#if DECODE_JPEG

#define False 0
#define True 1

/* JPEG decoder state. */
static Bool jpegError;
/*
 * JPEG source manager functions for JPEG decompression in Tight decoder.
 */
static struct jpeg_source_mgr jpegSrcManager;
static JOCTET *jpegBufferPtr;
static size_t jpegBufferLen;

static void
JpegInitSource(j_decompress_ptr cinfo)
{
  jpegError = False;
}

static boolean
JpegFillInputBuffer(j_decompress_ptr cinfo)
{
  jpegError = True;
  jpegSrcManager.bytes_in_buffer = jpegBufferLen;
  jpegSrcManager.next_input_byte = (JOCTET *)jpegBufferPtr;

  return TRUE;
}

static void
JpegSkipInputData(j_decompress_ptr cinfo, long num_bytes)
{
  if (num_bytes < 0 || num_bytes > jpegSrcManager.bytes_in_buffer) {
    jpegError = True;
    jpegSrcManager.bytes_in_buffer = jpegBufferLen;
    jpegSrcManager.next_input_byte = (JOCTET *)jpegBufferPtr;
  } else {
    jpegSrcManager.next_input_byte += (size_t) num_bytes;
    jpegSrcManager.bytes_in_buffer -= (size_t) num_bytes;
  }
}

static void
JpegTermSource(j_decompress_ptr cinfo)
{
  /* No work necessary here. */
}

static void
JpegSetSrcManager(j_decompress_ptr cinfo, CARD8 *compressedData,
		  int compressedLen)
{
  jpegBufferPtr = (JOCTET *)compressedData;
  jpegBufferLen = (size_t)compressedLen;

  jpegSrcManager.init_source = JpegInitSource;
  jpegSrcManager.fill_input_buffer = JpegFillInputBuffer;
  jpegSrcManager.skip_input_data = JpegSkipInputData;
  jpegSrcManager.resync_to_restart = jpeg_resync_to_restart;
  jpegSrcManager.term_source = JpegTermSource;
  jpegSrcManager.next_input_byte = jpegBufferPtr;
  jpegSrcManager.bytes_in_buffer = jpegBufferLen;

  cinfo->src = &jpegSrcManager;
}

static void
rf_host_jpeg_decode(void)
{
  TightInfo *t = get_tight_info(cur_slot);

  struct jpeg_decompress_struct cinfo;
  struct jpeg_error_mgr jerr;
  const int compressedLen = t->compressed_size;
  CARD8 *compressedData = cur_slot->readbuf;

  JSAMPROW rowPointer[1];
  int dx, dy;
  const int x = t->rect.x;
  const int y = t->rect.y;
  const int w = t->rect.w;
  const int h = t->rect.h;
#define BUFFER_SIZE (640 * 480) /* XXX fix?? */
  CARD8 buffer[BUFFER_SIZE];

  buffer[BUFFER_SIZE - 1] = 123; /* sanity check (see below) */

  /*
  printf("Decode jpeg block of length %d at %d, %d size %d x %d\n",
         compressedLen, x, y, w, h);
  */

  if (compressedLen <= 0) {
    fprintf(stderr, "Incorrect data received from the server.\n");
    return;
  }

  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_decompress(&cinfo);

  JpegSetSrcManager(&cinfo, compressedData, compressedLen);

  jpeg_read_header(&cinfo, TRUE);
  cinfo.out_color_space = JCS_RGB;

  jpeg_start_decompress(&cinfo);
  if (cinfo.output_width != w || cinfo.output_height != h ||
      cinfo.output_components != 3) {
    fprintf(stderr, "Tight Encoding: Wrong JPEG data received.\n");
    jpeg_destroy_decompress(&cinfo);
    free(compressedData);
    return;
  }

  rowPointer[0] = (JSAMPROW)buffer;
  dy = 0;
  while (cinfo.output_scanline < cinfo.output_height) {
    CARD32 *pixelPtr;
    jpeg_read_scanlines(&cinfo, rowPointer, 1);
    if (jpegError) {
      break;
    }

    pixelPtr = &g_framebuffer[(y + dy) * (int)g_fb_width + x];
    for (dx = 0; dx < w; dx++) {
       *pixelPtr++ = ((buffer[dx*3+0] << 16) |
                      (buffer[dx*3+1] << 8) |
                      (buffer[dx*3+2] << 0));
    }
    dy++;
  }

  if (!jpegError)
    jpeg_finish_decompress(&cinfo);

  jpeg_destroy_decompress(&cinfo);

  fbupdate_rect_done();

  assert(buffer[BUFFER_SIZE - 1] == 123); /* sanity check (see above) */
}


static void
rf_host_jpeg_len3(void)
{
   TightInfo *t = get_tight_info(cur_slot);
   CARD8 b = cur_slot->readbuf[0];
   t->compressed_size |= ((int) b & 0xFF) << 14;
   aio_setread(rf_host_jpeg_decode, NULL, t->compressed_size);
}

static void
rf_host_jpeg_len2(void)
{
   TightInfo *t = get_tight_info(cur_slot);
   CARD8 b = cur_slot->readbuf[0];
   t->compressed_size |= ((int) b & 0x7F) << 7;
   if (b & 0x80) {
      /* get third length byte */
      aio_setread(rf_host_jpeg_len3, NULL, 1);
   }
   else {
      aio_setread(rf_host_jpeg_decode, NULL, t->compressed_size);
   }
}

static void
rf_host_jpeg_len1(void)
{
   TightInfo *t = get_tight_info(cur_slot);
   CARD8 b = cur_slot->readbuf[0];
   t->compressed_size = (int) b & 0x7f;
   if (b & 0x80) {
      /* get second length byte */
      aio_setread(rf_host_jpeg_len2, NULL, 1);
   }
   else {
      aio_setread(rf_host_jpeg_decode, NULL, t->compressed_size);
   }
}

#endif /* JPEG */


static TightInfo *
alloc_tight_info(void)
{
   TightInfo *t = (TightInfo *) calloc(1, sizeof(TightInfo));
   t->zstream_active[0] = 0;
   t->zstream_active[1] = 0;
   t->zstream_active[2] = 0;
   t->zstream_active[3] = 0;
   t->reset_streams = 0;
   return t;
}

static void
set_tight_info(AIO_SLOT *s, TightInfo *t)
{
   if (t) {
      assert(!s->encoder_private);
   }
   s->encoder_private = (void *) t;
}


void reset_tight_streams(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  int stream_id;

  if (!t) {
     t = alloc_tight_info();
     set_tight_info(cur_slot, t);
  }
     
  for (stream_id = 0; stream_id < 4; stream_id++) {
    if (t->zstream_active[stream_id]) {
      if (inflateEnd(&t->zstream[stream_id]) != Z_OK) {
        if (t->zstream[stream_id].msg != NULL) {
          log_write(LL_WARN, "inflateEnd() failed: %s",
                    t->zstream[stream_id].msg);
        } else {
          log_write(LL_WARN, "inflateEnd() failed");
        }
      }
      t->zstream_active[stream_id] = 0;
      t->reset_streams |= (1 << stream_id);
    }
  }
}

void setread_decode_tight(FB_RECT *r)
{
  TightInfo *t = get_tight_info(cur_slot);
  if (!t) {
     t = alloc_tight_info();
     set_tight_info(cur_slot, t);
  }

  t->rect = *r;
  aio_setread(rf_host_tight_compctl, NULL, sizeof(CARD8));
}

static void rf_host_tight_compctl(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  CARD8 comp_ctl;
  int stream_id;

  fbs_spool_byte(cur_slot->readbuf[0] | t->reset_streams);
  t->reset_streams = 0;

  /* Compression control byte */
  comp_ctl = cur_slot->readbuf[0];

  /* Flush zlib streams if we are told by the server to do so */
  for (stream_id = 0; stream_id < 4; stream_id++) {
    if ((comp_ctl & (1 << stream_id)) && t->zstream_active[stream_id]) {
      if (inflateEnd(&t->zstream[stream_id]) != Z_OK) {
        if (t->zstream[stream_id].msg != NULL) {
          log_write(LL_WARN, "inflateEnd() failed: %s",
                    t->zstream[stream_id].msg);
        } else {
          log_write(LL_WARN, "inflateEnd() failed");
        }
      }
      t->zstream_active[stream_id] = 0;
    }
  }
  comp_ctl &= 0xF0;             /* clear bits 3..0 */

  if (comp_ctl == RFB_TIGHT_FILL) {
    aio_setread(rf_host_tight_fill, NULL, 3);
  }
  else if (comp_ctl == RFB_TIGHT_JPEG) {
#if DECODE_JPEG
    aio_setread(rf_host_jpeg_len1, NULL, 1);
#else
    log_write(LL_ERROR, "JPEG is not supported on host connections");
    aio_close(0);
#endif
    return;
  }
  else if (comp_ctl > RFB_TIGHT_MAX_SUBENCODING) {
    log_write(LL_ERROR, "Invalid sub-encoding in Tight-encoded data");
    aio_close(0);
    return;
  }
  else {                        /* "basic" compression */
    t->stream_id = (comp_ctl >> 4) & 0x03;
    if (comp_ctl & RFB_TIGHT_EXPLICIT_FILTER) {
      aio_setread(rf_host_tight_filter, NULL, 1);
    } else {
      t->filter_id = RFB_TIGHT_FILTER_COPY;
      t->uncompressed_size = t->rect.w * t->rect.h * 3;
      if (t->uncompressed_size < RFB_TIGHT_MIN_TO_COMPRESS) {
        aio_setread(rf_host_tight_raw, NULL, t->uncompressed_size);
      } else {
        aio_setread(rf_host_tight_len1, NULL, 1);
      }
    }
  }
}

static void rf_host_tight_fill(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  CARD32 color;

  fbs_spool_data(cur_slot->readbuf, 3);

  /* Note: cur_slot->readbuf is unsigned char[]. */
  color = (cur_slot->readbuf[0] << 16 |
           cur_slot->readbuf[1] << 8 |
           cur_slot->readbuf[2]);

  log_write(LL_DEBUG, "Decompress tight solid color (%d,%d,%d) rect %d x %d",
            cur_slot->readbuf[0],
            cur_slot->readbuf[1],
            cur_slot->readbuf[2],
            t->rect.w, t->rect.h);

  fill_fb_rect(&t->rect, color);
  fbupdate_rect_done();
  /*set_tight_info(cur_slot, NULL);*/
}

static void rf_host_tight_filter(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  fbs_spool_byte(cur_slot->readbuf[0]);

  t->filter_id = cur_slot->readbuf[0];
  if (t->filter_id == RFB_TIGHT_FILTER_PALETTE) {
    aio_setread(rf_host_tight_numcolors, NULL, 1);
  } else {
    if (t->filter_id != RFB_TIGHT_FILTER_COPY &&
        t->filter_id != RFB_TIGHT_FILTER_GRADIENT) {
      log_write(LL_ERROR, "Unrecognized filter ID in the Tight decoder");
      aio_close(0);
      return;
    }
    t->uncompressed_size = t->rect.w * t->rect.h * 3;
    if (t->uncompressed_size < RFB_TIGHT_MIN_TO_COMPRESS) {
      aio_setread(rf_host_tight_raw, NULL, t->uncompressed_size);
    } else {
      aio_setread(rf_host_tight_len1, NULL, 1);
    }
  }
}

static void rf_host_tight_numcolors(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  fbs_spool_data(cur_slot->readbuf, 1);

  t->num_colors = cur_slot->readbuf[0] + 1;
  aio_setread(rf_host_tight_palette, NULL, t->num_colors * 3);
}

static void rf_host_tight_palette(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  int i, row_size;

  fbs_spool_data(cur_slot->readbuf, t->num_colors * 3);

  for (i = 0; i < t->num_colors; i++) {
    t->palette[i] = (cur_slot->readbuf[i*3] << 16 |
                    cur_slot->readbuf[i*3+1] << 8 |
                    cur_slot->readbuf[i*3+2]);
  }
  row_size = (t->num_colors <= 2) ? (t->rect.w + 7) / 8 : t->rect.w;
  t->uncompressed_size = t->rect.h * row_size;
  if (t->uncompressed_size < RFB_TIGHT_MIN_TO_COMPRESS) {
    aio_setread(rf_host_tight_indexed, NULL, t->uncompressed_size);
  } else {
    aio_setread(rf_host_tight_len1, NULL, 1);
  }
}

static void rf_host_tight_raw(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  fbs_spool_data(cur_slot->readbuf, t->uncompressed_size);

  tight_draw_truecolor_data(cur_slot->readbuf);
  fbupdate_rect_done();
  /*set_tight_info(cur_slot, NULL);*/
}

static void rf_host_tight_indexed(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  fbs_spool_data(cur_slot->readbuf, t->uncompressed_size);

  tight_draw_indexed_data(cur_slot->readbuf);
  fbupdate_rect_done();
  /*set_tight_info(cur_slot, NULL);*/
}

static void rf_host_tight_len1(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  fbs_spool_byte(cur_slot->readbuf[0]);

  t->compressed_size = cur_slot->readbuf[0] & 0x7F;
  if (cur_slot->readbuf[0] & 0x80) {
    aio_setread(rf_host_tight_len2, NULL, 1);
  } else {
    aio_setread(rf_host_tight_compressed, NULL, t->compressed_size);
  }
}

static void rf_host_tight_len2(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  fbs_spool_byte(cur_slot->readbuf[0]);

  t->compressed_size |= (cur_slot->readbuf[0] & 0x7F) << 7;
  if (cur_slot->readbuf[0] & 0x80) {
    aio_setread(rf_host_tight_len3, NULL, 1);
  } else {
    aio_setread(rf_host_tight_compressed, NULL, t->compressed_size);
  }
}


static void rf_host_tight_len3(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  fbs_spool_byte(cur_slot->readbuf[0]);

  t->compressed_size |= (cur_slot->readbuf[0] & 0x7F) << 14;
  aio_setread(rf_host_tight_compressed, NULL, t->compressed_size);
}

static void rf_host_tight_compressed(void)
{
  TightInfo *t = get_tight_info(cur_slot);
  z_streamp zs;
  CARD8 *buf;
  int err;

  fbs_spool_data(cur_slot->readbuf, t->compressed_size);

  /* Initialize compression stream if needed */

  zs = &t->zstream[t->stream_id];
  if (!t->zstream_active[t->stream_id]) {
    zs->zalloc = Z_NULL;
    zs->zfree = Z_NULL;
    zs->opaque = Z_NULL;
    err = inflateInit(zs);
    if (err != Z_OK) {
      if (zs->msg != NULL) {
        log_write(LL_ERROR, "inflateInit() failed: %s", zs->msg);
      } else {
        log_write(LL_ERROR, "inflateInit() failed");
      }
      aio_close(0);
      return;
    }
    t->zstream_active[t->stream_id] = 1;
  }

  /* Allocate a buffer to put decompressed data into */

  buf = malloc(t->uncompressed_size);
  if (buf == NULL) {
    log_write(LL_ERROR, "Error allocating memory in Tight decoder");
    aio_close(0);
    return;
  }

  /* Decompress the data */

  zs->next_in = cur_slot->readbuf;
  zs->avail_in = t->compressed_size;
  zs->next_out = buf;
  zs->avail_out = t->uncompressed_size;

  log_write(LL_DEBUG, "Decompress tight from %d to %d bytes (ratio=%.3f)",
            t->compressed_size, t->uncompressed_size,
            (float) t->uncompressed_size / (float) t->compressed_size);

  err = inflate(zs, Z_SYNC_FLUSH);
  if (err != Z_OK && err != Z_STREAM_END) {
    if (zs->msg != NULL) {
      log_write(LL_ERROR, "inflate() failed: %s", zs->msg);
    } else {
      log_write(LL_ERROR, "inflate() failed: %d", err);
    }
    free(buf);
    aio_close(0);
    return;
  }

  if (zs->avail_out > 0)
    log_write(LL_WARN, "Decompressed data size is less than expected");

  /* Draw the data on the framebuffer */

  if (t->filter_id == RFB_TIGHT_FILTER_PALETTE) {
    tight_draw_indexed_data(buf);
  } else if (t->filter_id == RFB_TIGHT_FILTER_GRADIENT) {
    tight_draw_gradient_data(buf);
  } else {
    tight_draw_truecolor_data(buf);
  }

  free(buf);

  fbupdate_rect_done();
  /*set_tight_info(cur_slot, NULL);*/
}

/*
 * Draw 24-bit truecolor pixel array on the framebuffer.
 */

static void tight_draw_truecolor_data(CARD8 *src)
{
  TightInfo *t = get_tight_info(cur_slot);
  int x, y;
  CARD32 *fb_ptr;
  CARD8 *read_ptr;

  fb_ptr = &g_framebuffer[t->rect.y * (int)g_fb_width + t->rect.x];
  read_ptr = src;

  for (y = 0; y < t->rect.h; y++) {
    for (x = 0; x < t->rect.w; x++) {
      *fb_ptr++ = read_ptr[0] << 16 | read_ptr[1] << 8 | read_ptr[2];
      read_ptr += 3;
    }
    fb_ptr += g_fb_width - t->rect.w;
  }
}

/*
 * Draw indexed data on the framebuffer, each source pixel is either 1
 * bit (two colors) or 8 bits (up to 256 colors).
 */

static void tight_draw_indexed_data(CARD8 *src)
{
  TightInfo *t = get_tight_info(cur_slot);
  int x, y, b, w;
  CARD32 *fb_ptr;
  CARD8 *read_ptr;

  fb_ptr = &g_framebuffer[t->rect.y * (int)g_fb_width + t->rect.x];
  read_ptr = src;

  if (t->num_colors <= 2) {
    w = (t->rect.w + 7) / 8;
    for (y = 0; y < t->rect.h; y++) {
      for (x = 0; x < t->rect.w / 8; x++) {
        for (b = 7; b >= 0; b--) {
          *fb_ptr++ = t->palette[*read_ptr >> b & 1];
        }
        read_ptr++;
      }
      for (b = 7; b >= 8 - t->rect.w % 8; b--) {
        *fb_ptr++ = t->palette[*read_ptr >> b & 1];
      }
      if (t->rect.w & 0x07)
        read_ptr++;
      fb_ptr += g_fb_width - t->rect.w;
    }
  } else {
    for (y = 0; y < t->rect.h; y++) {
      for (x = 0; x < t->rect.w; x++) {
        *fb_ptr++ = t->palette[*read_ptr++];
      }
      fb_ptr += g_fb_width - t->rect.w;
    }
  }
}

/*
 * Restore and draw the data processed with the "gradient" filter.
 */

static void tight_draw_gradient_data(CARD8 *src)
{
  TightInfo *t = get_tight_info(cur_slot);
  int x, y, c;
  CARD32 *fb_ptr;
  CARD8 prev_row[2048*3];
  CARD8 this_row[2048*3];
  CARD8 pix[3];
  int est;

  fb_ptr = &g_framebuffer[t->rect.y * (int)g_fb_width + t->rect.x];

  memset(prev_row, 0, t->rect.w * 3);

  for (y = 0; y < t->rect.h; y++) {

    /* First pixel in a row */
    for (c = 0; c < 3; c++) {
      pix[c] = prev_row[c] + src[y*t->rect.w*3+c];
      this_row[c] = pix[c];
    }
    *fb_ptr++ = pix[0] << 16 | pix[1] << 8 | pix[2];

    /* Remaining pixels of a row */
    for (x = 1; x < t->rect.w; x++) {
      for (c = 0; c < 3; c++) {
	est = (int)prev_row[x*3+c] + (int)pix[c] - (int)prev_row[(x-1)*3+c];
	if (est > 0xFF) {
	  est = 0xFF;
	} else if (est < 0x00) {
	  est = 0x00;
	}
	pix[c] = (CARD8)est + src[(y*t->rect.w+x)*3+c];
	this_row[x*3+c] = pix[c];
      }
      *fb_ptr++ = pix[0] << 16 | pix[1] << 8 | pix[2];
    }

    fb_ptr += g_fb_width - t->rect.w;
    memcpy(prev_row, this_row, t->rect.w * 3);
  }
}

