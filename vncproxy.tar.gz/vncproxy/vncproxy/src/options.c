#include <sys/types.h>
#include <string.h>
#include "logging.h"
#include "options.h"
#include "rfblib.h"


struct options opt;


void init_options(struct options *opt)
{
  memset(opt, 0, sizeof(*opt));

  opt->no_banner = 1;
  opt->foreground = 1;
  opt->stderr_loglevel = LL_WARN;
  opt->file_loglevel = -1;
  opt->passwd_filename = NULL;
  opt->log_filename = NULL;
  opt->active_filename = NULL;
  opt->cl_listen_port = -1;
  opt->pid_file[0] = '\0';
  opt->fbs_prefix = NULL;
  opt->join_sessions = 0;
  opt->bind_ip = NULL;
  opt->pref_encoding = RFB_ENCODING_RAW;
  opt->tight_level = -1;
  opt->jpeg_quality = -1; /* no jpeg encoding */
  opt->host_info_file = NULL;
  opt->java_path = NULL;

  opt->res_scale = 1;
}
