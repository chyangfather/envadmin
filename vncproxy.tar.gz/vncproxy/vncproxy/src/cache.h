#ifndef CACHE_H
#define CACHE_H

#include "rfblib.h"
#include "region.h"
#include "host_io.h"
#include "client_io.h"

extern void
cache_data(struct cache_entry *ent, const unsigned char *data, size_t bytes);

extern void
begin_caching(HOST_SLOT *hs);

extern void
cache_rect(HOST_SLOT *hs, const FB_RECT *r);

extern void
end_caching(HOST_SLOT *hs);

extern int
cache_search(CL_SLOT *cl, RegionPtr remainder);

extern int
cache_send(const RegionPtr region, const char *where, int *containsCenterPixel);

#endif /* CACHE_H */


