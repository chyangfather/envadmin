/**
 * Syncronization module
 * Copyright 2006 Tungsten Graphics, Inc.
 *
 * Author: Brian Paul
 */

/**
 * Frame synchronization for 3D rendering.
 *
 * Problem description:
 *   When connected to a DMX display, we're getting RFB streams from
 *   multiple VNC SPUs.  Without some kind of synchronization, we may
 *   update different regions of the proxy's virtual framebuffer at
 *   different rates, resulting in temporal "tearing" showing up in the
 *   VNC viewer.  In other words, some screen regions may be several frames
 *   behind others.
 *
 *   Also, there are times when the remote viewer doesn't want any 3D
 *   frames to be dropped; the application shoulnd render no faster than
 *   the viewer can process updates.
 *
 * Solution:
 *   Carefully coordinate the incoming updates (from the upstream VNC SPUs)
 *   and the outgoing updates (to the VNC viewers).
 *
 * Implementation:
 *   When we get an RFB update message from any of the VNC SPUs (i.e. a
 *   new 3D frame), we initiate a barrier.  For each VNC SPU stream that
 *   hits the barrier, the barrier count is incremented and the socket
 *   corresponding to the stream is suspended.  When the barrier is active,
 *   we also prevent RFB updates from being sent to the viewers.
 *
 *   After we've received all 'N' RFB updates we send RFB updates to all
 *   the VNC viewers.  Then, the barrier is released so we un-suspend all
 *   the VNC SPU sockets so we can receive the next frame's update.
 *
 *   If there are no RFB updates coming from the VNC SPUs, it means the
 *   OpenGL app is idle.  We continue processing RFB updates from the
 *   DMX servers, though, so that normal Xlib rendering appears in the
 *   viewer.
 */


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <zlib.h>

#include "rfblib.h"
#include "reflector.h"
#include "async_io.h"
#include "host_io.h"
#include "client_io.h"
#include "sync.h"


#define STATE_PRE_UPDATE  0
#define STATE_MID_UPDATE  1
#define STATE_POST_UPDATE 2

#define DEBUG_SYNC 0


struct sync_group {
   int size;           /* equals number of VNC SPUs */
   int count;          /* current barrier count */
   HOST_SLOT **slots;  /* array [size] of HOST_SLOT pointers */
   int *ports;         /* array [size] of port for each host slot */
   int *state;         /* array [size] of STATE_* values */
   int *fcount;        /* array [size] of frame count, for debugging */
   int active;

   int port;           /* which VNC SPU port this group corresponds to */
   int teardown;       /* are hosts being removed? */

   struct sync_group *next; /* next sync group in linked list */
};

static struct sync_group *GroupHead = NULL;

static struct sync_group *RecentGroup = NULL;

static int GroupSize = 0;


/**
 * Search all sync groups for the given host and return the group to which
 * it belongs.
 */
static struct sync_group *
find_group(HOST_SLOT *hs)
{
   struct sync_group *g;
   for (g = GroupHead; g; g = g->next) {
      int i;
      for (i = 0; i < g->size; i++) {
         if (g->slots[i] == hs) {
            return g;
         }
      }
   }
   return NULL;
}


static struct sync_group *
lookup_group_by_port(int port)
{
   struct sync_group *g;
   for (g = GroupHead; g; g = g->next) {
      if (g->port == port)
         return g;
   }
   return NULL;
}


static struct sync_group *
new_sync_group(int size, int port)
{
   struct sync_group *g;

#if DEBUG_SYNC
   printf("Allocating new sync group\n");
#endif

   g = (struct sync_group *) calloc(1, sizeof(struct sync_group));
   assert(size >= 1);
   if (g) {
      g->size = size;
      g->slots = (HOST_SLOT **) calloc(g->size, sizeof(HOST_SLOT *));
      g->ports = (int *) calloc(g->size, sizeof(int));
      g->state = (int *) calloc(g->size, sizeof(int));
      g->fcount = (int *) calloc(g->size, sizeof(int));
      g->port = port;
   }

   return g;
}


/**
 * Delete the given sync_group and remove from linked list.
 */
static void
delete_group(struct sync_group *g)
{
   struct sync_group *prev = NULL, *grp;

   if (RecentGroup == g)
      RecentGroup = NULL;

   for (grp = GroupHead; grp; grp = grp->next) {
      if (grp == g) {
         if (prev)
            prev->next = g->next;
         else
            GroupHead = g->next;
         free(g->slots);
         free(g->ports);
         free(g->state);
         free(g->fcount);
         free(g);
         return;
      }
      prev = grp;
   }
}



/**
 * Sets the sync group size for all groups we'll create.
 * This will be the number of screens in the DMX display.
 */
void
sync_group_size(int size)
{
   assert(!GroupSize);
   assert(size >= 1);
#if DEBUG_SYNC
   printf("Init GroupSize = %d\n", size);
#endif
   GroupSize = size;
}


/**
 * Add a host to the given sync group.  If <g> is null, create a new group.
 */
struct sync_group *
sync_add_host(HOST_SLOT *hs, int port)
{
   struct sync_group *g = lookup_group_by_port(port);
   int i;

   if (!GroupSize) {
      /* no synchronization */
      return NULL;
   }

   assert(hs->s.name);
   assert(hs->s.name[0]);

   if (!g) {
      /* new group */
      g = new_sync_group(GroupSize, port);
      g->next = GroupHead;
      GroupHead = g;
   }

#if DEBUG_SYNC
   printf("Add host %p to group %p, port %d\n", (void*) hs, (void*) g, port);
#endif

   if (!g->teardown) {
      for (i = 0; i < g->size; i++) {
         if (g->slots[i] && strcmp(g->slots[i]->s.name, hs->s.name) == 0) {
            /* duplicated host */
            return g;
            /*break;*/
         }
         if (!g->slots[i]) {
            g->slots[i] = hs;
            /* OK, we've added this host to this group */
            return g;
         }
      }
   }

   return NULL;
}


void
sync_remove_host(HOST_SLOT *hs)
{
   struct sync_group *g = find_group(hs);
   int i, numEmpty;

#if DEBUG_SYNC
   printf("Remove host %p\n", (void*) hs);
#endif

   if (!g)
      return;

   g->teardown = 1;

   /* Two things:
    * Clear all slots' suspended fields (prevents proxy deadlocks).
    * Remove slot from sync group's list of slots.
    */
   for (i = 0; i < g->size; i++) {
      /* unsuspend */
      if (g->slots[i]) {
         aio_suspend_slot(&g->slots[i]->s, UNSUSPEND);
      }
      /* remove */
      if (g->slots[i] == hs) {
         g->slots[i] = NULL;
         g->state[i] = STATE_PRE_UPDATE;
      }
   }

   numEmpty = 0;
   for (i = 0; i < g->size; i++) {
      if (!g->slots[i])
         numEmpty++;
   }
   if (numEmpty == g->size) {
      delete_group(g);
   }
}


/**
 * Release a sync barrier when we've found that everyone's ready.
 */
static void
release_group(struct sync_group *g, int force)
{
   int i;
   for (i = 0; i < g->size; i++) {
      if (g->slots[i]) {
         if (!force) {
            /*
            assert(g->state[i] == STATE_POST_UPDATE);
            */
         }
         /* unblock socket */
         aio_suspend_slot(&g->slots[i]->s, UNSUSPEND);
      }
      g->state[i] = STATE_PRE_UPDATE;
   }
   g->count = 0;
   g->active = 0;
}


static void
update_client(CL_SLOT *cl)
{
  assert(cl->s.type == TYPE_CL_SLOT);
  if (/*cl->update_requested &&*/
      (cl->newfbsize_pending ||
       REGION_NOTEMPTY(&cl->pending_region) ||
       REGION_NOTEMPTY(&cl->copy_region))) {
     if (!cl->update_in_progress && cl->connected) {
        AIO_SLOT *save = cur_slot;
        cur_slot = &cl->s;
        send_update("update_client");
        cur_slot = save;
     }
  }
}



static int SyncWaitCount = 0;

/**
 * Send RFB updates to all clients
 * return number of client connections
 */
static int
send_client_updates(void)
{
   AIO_SLOT *s;
   int count = 0;
#if DEBUG_SYNC
   printf("send RFB updates to all clients\n");
#endif
   SyncWaitCount = 0;
   for (s = aio_first_slot(); s; s = s->next) {
      if (s->type == TYPE_CL_SLOT) {
         CL_SLOT *cl = (CL_SLOT*) s;
#if DEBUG_SYNC
         printf("  send RFB update to %p\n", (void*) cl);
#endif
         update_client(cl);
         cl->sync_wait = 1;
         SyncWaitCount++;
         count++;
      }
   }
   /* now, we won't release the group barrier until we get an
    * RFB Update Request from each of the viewers.  The number of requests
    * we need is 'SyncWaitCount'.
    */
   return count;
}


/**
 * Release all groups when a client goes away
 */
void
sync_remove_client(CL_SLOT *cl)
{
   struct sync_group *g;
#if DEBUG_SYNC
   printf("Removing client\n");
#endif
   for (g = GroupHead; g; g = g->next) {
      release_group(g, 1);
   }
   SyncWaitCount = 0;
}



/**
 * Called when we begin receiving an RFB update from a VNC server.
 */
void
sync_begin_recv_update(HOST_SLOT *hs)
{
   struct sync_group *g = find_group(hs);
   int i;

#if DEBUG_SYNC
   printf("Begin Recv Update on %p, group %p\n", (void *) hs, (void *) g);
#endif

   if (!g) {
      return;
   }

   assert(hs->is_vnc_spu);

   RecentGroup = g;
   g->active = 1;

   /* find the slot, update its state to MID-UPDATE */
   for (i = 0; i < g->size; i++) {
      /*assert(g->slots[i]);*/
      if (g->slots[i] == hs) {
         assert(hs->is_vnc_spu);
         /*
         assert(g->state[i] == STATE_PRE_UPDATE);
         */
         g->state[i] = STATE_MID_UPDATE;
         g->fcount[i]++;
         return;
      }
   }
}


/**
 * Called when we finish receiving an RFB update from a VNC server.
 */
void
sync_end_recv_update(HOST_SLOT *hs)
{
   struct sync_group *g = find_group(hs);
   int i;

#if DEBUG_SYNC
   printf("End Recv Update on %p\n", (void *) hs);
#endif

   if (!g || !g->active)
      return;

   /* find the slot, update its state to POST-UPDATE */
   for (i = 0; i < g->size; i++) {
      if (g->slots[i] == hs) {
         /*assert(g->state[i] == STATE_MID_UPDATE);*/
         g->state[i] = STATE_POST_UPDATE;
         if (!g->teardown)
            aio_suspend_slot(&hs->s, SUSPEND_READ);
         g->count++;
#if DEBUG_SYNC
         /*printf("Count = %d of %d (%d %d)\n",
           g->count, g->size, g->fcount[0], g->fcount[1]);
         */
         printf("Count = %d of %d\n", g->count, g->size);
#endif
         break;
      }
   }

   /* if the barrier's count == size, time to release it */
   if (g->count == g->size) {
#if DEBUG_SYNC
      printf("  Release all\n");
#endif
      if (send_client_updates() == 0) {
        /* no clients, release barrier */
        release_group(g, 1);
      }

#if 0
      release_group(g);
#endif
   }
}


/**
 * Called when we get an RFB update request from a client.
 */
void
sync_recv_update_request(CL_SLOT *cl)
{
   struct sync_group *g;

   if (cl->sync_wait) {
      cl->sync_wait = 0;
      SyncWaitCount--;
   }

   if (SyncWaitCount <= 0) {
      /* we've got all the RFB update requests we're waiting for */
      for (g = GroupHead; g; g = g->next) {
         if (g->active && g->count == g->size) {
            release_group(g, 0);
         }
      }
   }
}



/**
 * Check if we're currently in the middle of receiving a synchronized update.
 */
int
sync_blocked(void)
{
   struct sync_group *g;

   for (g = GroupHead; g; g = g->next) {
      if (!g->teardown && g->active) {
#if DEBUG_SYNC
         printf("sync blocked\n");
#endif
         return 1;
      }
   }

   return 0;
}
