/* VNC Reflector
 * Copyright (C) 2001-2003 HorizonLive.com, Inc.  All rights reserved.
 *
 * This software is released under the terms specified in the file LICENSE,
 * included.  HorizonLive provides e-Learning and collaborative synchronous
 * presentation solutions in a totally Web-based environment.  For more
 * information about HorizonLive, please see our website at
 * http://www.horizonlive.com.
 *
 * This software was authored by Constantin Kaplinsky <const@ce.cctpu.edu.ru>
 * and sponsored by HorizonLive.com, Inc.
 *
 * $Id: host_connect.c,v 1.26 2007/05/28 17:01:27 brianp Exp $
 * Connecting to a VNC host
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pwd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <ctype.h>
#include <zlib.h>
#ifdef USE_DMX
#include <X11/Xlib.h>
#include <X11/extensions/dmxext.h>
#endif

#include "rfblib.h"
#include "reflector.h"
#include "logging.h"
#include "async_io.h"
#include "host_io.h"
#include "translate.h"
#include "client_io.h"
#include "encode.h"
#include "host_connect.h"
#include "http.h"
#include "sync.h"
#include "options.h"

/**
 * We have a range of ports that we try to use.
 * Need this to support multiple, simultaneous SPUs running on one host.
 */
#define FIRST_SERVER_PORT  5905
#define NUM_SERVER_PORTS     10


/* for various pieces of the RFB 3.7 protocol: */
typedef struct {
  CARD32 code;
  CARD8 vendor[4];
  CARD8 name[8];
} CapInfo;


static int parse_host_info(const char *fname);
static void host_init_hook(void);
static void host_listen_init_hook(void);
static void host_accept_hook(void);
static void rf_host_ver(void);
static void rf_host_auth(void);
static void rf_host_conn_failed_len(void);
static void rf_host_conn_failed(void);
static void rf_host_crypt(void);
static void rf_host_auth_done(void);
static void send_client_initmsg(void);
static void rf_host_initmsg(void);
static void rf_host_set_formats(void);

static void rf_host_security_type_count(void);
static void rf_host_security_types(void);
static void rf_host_num_tunnel_types(void);
static void rf_host_num_auths(void);
static void rf_host_auths(void);
static void send_unix_authentication(void);
static void rf_host_interaction_caps_len(void);
static void rf_host_encoding_types(void);

static int s_pref_encoding;
static int s_tight_level;

static int s_cl_listen_port;

static char s_hostname[256];
static char s_host_password[10];


/**
 * If we're little endian, return byte-swapped value.
 */
static CARD32
Swap32(CARD32 k)
{
   const int one = 1;
   const char *littleEndian = (const char *) &one;
   if (*littleEndian) {
      return (((k) & 0xff000000) >> 24) |
             (((k) & 0x00ff0000) >> 8)  |
             (((k) & 0x0000ff00) << 8)  |
             (((k) & 0x000000ff) << 24);
   }
   else {
      return k;
   }
}


void set_client_listen_port(int port)
{
  s_cl_listen_port = port;
}


/*
 * Set preferred encoding (Hextile or Tight) and compression level
 * for the Tight encoding.
 */

void set_host_encodings(int pref_encoding, int tight_level)
{
  assert(pref_encoding == RFB_ENCODING_HEXTILE ||
         pref_encoding == RFB_ENCODING_TIGHT ||
         pref_encoding == RFB_ENCODING_RAW ||
         pref_encoding == RFB_ENCODING_RAW24);
  s_pref_encoding = pref_encoding;
  s_tight_level = tight_level;
}


/*
 * Parse "host::port" or "host:dpyNum" string.
 */
static void
parse_displayname(const char *dpyName, char *host, int *port)
{
  char *colon;
  *port = 5900;
  strcpy(host, dpyName);
  colon = strchr(host, ':');
  if (colon) {
    *colon = 0;
    if (colon[1] == ':') {
      /* hostname::port */
      *port = atoi(colon + 2);
    }
    else {
      /* hostname:displaynumber */
      *port = 5900 + atoi(colon + 1);
    }
  }
  if (host[0] == 0) {
    strcpy(host, "localhost");
  }
}


/*
 * Connect to a remote RFB host
 * Return 0 if error, 1 if success.
 */
HOST_SLOT *
connect_to_host(const char *hostname, const char *dpyName,
                int port, int x, int y, int is_input_only)
{
   HOST_SLOT *hs;

   if (strcmp(hostname, "*") == 0) {
      /* Reversed host -> reflector connection, start listening */
      /* XXX this is probably broken now */

      if (port == 0)
         port = 5500;

      hs = (HOST_SLOT *) aio_listen(port, host_listen_init_hook,
                                    host_accept_hook, sizeof(HOST_SLOT));
      if (!hs) {
         log_write(LL_ERROR, "Error creating listening socket: %s",
                   strerror(errno));
         return NULL;
      }

      log_write(LL_MSG, "Listening for host connections on port %d", port);
      /* XXX FIX */
      hs->fb_x_origin = 0;
      hs->fb_y_origin = 0;
   }
   else {
      int host_fd;
      struct hostent *phe;
      struct sockaddr_in host_addr;

      assert(port);

      /* Forward reflector -> host connection */
      log_write(LL_MSG, "Connecting to %s, port %d (%d, %d)", hostname, port, x, y);

      phe = gethostbyname(hostname);
      if (phe == NULL) {
        log_write(LL_ERROR, "Could not get host address: %s", strerror(errno));
        return NULL;
      }

      host_addr.sin_family = AF_INET;
      memcpy(&host_addr.sin_addr.s_addr, phe->h_addr, phe->h_length);
      host_addr.sin_port = htons((unsigned short)port);

      host_fd = socket(AF_INET, SOCK_STREAM, 0);
      if (host_fd == -1) {
        log_write(LL_ERROR, "Could not create socket: %s", strerror(errno));
        return NULL;
      }

      if (connect(host_fd, (struct sockaddr *)&host_addr,
                  sizeof(host_addr)) != 0) {
        /* caller should report error */
        close(host_fd);
        return NULL;
      }

      log_write(LL_MSG, "Connection established (fd=%d)", host_fd);

      hs = (HOST_SLOT *) aio_add_slot(host_fd, hostname,
                                      host_init_hook, sizeof(HOST_SLOT));
      if (!hs)
        return NULL;

      aio_set_slot_displayname(&hs->s, dpyName);
      hs->is_input_only = is_input_only;
      if (is_input_only) {
        hs->fb_x_origin = 0;
        hs->fb_y_origin = 0;
      }
      else {
        hs->fb_x_origin = x;
        hs->fb_y_origin = y;
      }
   }

   return hs;
}


#ifdef USE_DMX

struct dmx_info {
  const char *dpy_name;
  int num_screens;
  DMXScreenAttributes *screen_info; /* array [num_screens] */
};

static struct dmx_info *TheDMXDisplay = NULL;


int
get_dmx_num_screens(void)
{
  if (TheDMXDisplay)
    return TheDMXDisplay->num_screens;
  else
    return 0;
}

static struct dmx_info *
allocate_dmx_info(const char *dpyName, int numScreens)
{
  struct dmx_info *d = (struct dmx_info *) malloc(sizeof(struct dmx_info));
  if (!d)
    return NULL;

  d->num_screens = numScreens;
  d->dpy_name = strdup(dpyName);
  d->screen_info = (DMXScreenAttributes *)
     malloc(numScreens * sizeof(DMXScreenAttributes));
  if (!d->screen_info) {
    free(d);
    return NULL;
  }

  return d;
}

int
get_dmx_screen_position(const char *backendDpyName, int *xpos, int *ypos)
{
  struct dmx_info *d = TheDMXDisplay;
  int i;
  if (!d)
    return 0;
  for (i = 0; i < d->num_screens; i++) {
    if (strcmp(d->screen_info[i].displayName, backendDpyName) == 0) {
      *xpos = d->screen_info[i].rootWindowXorigin;
      *ypos = d->screen_info[i].rootWindowYorigin;
      return 1;
    }
  }
  return 0;
}

#endif /* USE_DMX */


int
connect_to_display(const char *displayName, int x, int y)
{
  char host[1000];
  int port;
  HOST_SLOT *hs;

  log_write(LL_DEBUG, "connect_to_display(%s, %d, %d)", displayName, x, y);

#ifdef USE_DMX
  if (!strstr(displayName, "::")) {
    /* displayName really is an X display name */
    int event_base, error_base;
    Display *dpy = XOpenDisplay(displayName);
    if (dpy) {

      if (DMXQueryExtension(dpy, &event_base, &error_base)) {
        /* this is a DMX display */
        int numScreens, i, k;
        int totalWidth, totalHeight;
        struct dmx_info *d = NULL;
        HOST_SLOT *hs;

        totalWidth = DisplayWidth(dpy, DefaultScreen(dpy));
        totalHeight = DisplayHeight(dpy, DefaultScreen(dpy));

        DMXGetScreenCount(dpy, &numScreens);
        assert(numScreens > 0);

        log_write(LL_MSG, "Connecting to (%d x %d) DMX display %s",
                  totalWidth, totalHeight, displayName);

        /* Connect to the DMX X server's VNC server in input-only mode */
        parse_displayname(displayName, host, &port);
        port++;
        port = 5901; /* XXX make this a config option? */
        hs = connect_to_host(host, displayName, port, 0, 0, 1);
        if (!hs) {
          log_write(LL_ERROR, "Unable to connect to DMX VNC server at %s::%d",
                    host, port);
          XCloseDisplay(dpy);
          return 0;
        }

        /* we'll send mouse/keyboard events to this host */
        set_master_host(hs);

        if (TheDMXDisplay) {
          log_write(LL_ERROR, "Already connected to DMX display!!!");
        }
        else {
          TheDMXDisplay = allocate_dmx_info(displayName, numScreens);
          d = TheDMXDisplay;
        }

        if (opt.frame_sync) {
          /* Synchronize updates from the SPU VNC servers to prevent
           * tearing, dropped frames.
           */
          sync_group_size(numScreens);
        }

        /* connect to the back-end X servers' VNC servers */
        for (i = 0; i < numScreens; i++) {
          int width, height, xoffset, yoffset;
          int p;

          if (!DMXGetScreenAttributes(dpy, i, d->screen_info + i)) {
            XCloseDisplay(dpy);
            return 0;
          }

          width = d->screen_info[i].screenWindowWidth;
          height = d->screen_info[i].screenWindowHeight;
          xoffset = d->screen_info[i].rootWindowXorigin;
          yoffset = d->screen_info[i].rootWindowYorigin;

          log_write(LL_MSG, "Screen %d: %s %d x %d at %d, %d",
                    i, d->screen_info[i].displayName,
                    width, height, xoffset, yoffset);

          parse_displayname(d->screen_info[i].displayName, host, &port);
          hs = connect_to_host(host, d->screen_info[i].displayName,
                               port, xoffset, yoffset, 0);
          if (!hs) {
            log_write(LL_ERROR,
                      "Unable to connect to back-end X VNC Server at %s::%d",
                      host, port);
            return 0;
          }

          /* try to connect to any/all Chromium VNC SPUs that may be running */
          k = 0;
          for (p = 0; p < NUM_SERVER_PORTS; p++) {
            const int vncSPUport = FIRST_SERVER_PORT + p;
            /* report no errors here */
            HOST_SLOT *crhs; /* chromium host slot */
            crhs = connect_to_host(host, d->screen_info[i].displayName,
                                 vncSPUport, xoffset, yoffset, 0);
            if (crhs) {
              crhs->is_vnc_spu = 1;
              crhs->dmx_host = hs;
              sync_add_host(crhs, vncSPUport);
            }
            k++;
          }
        }

        log_write(LL_MSG, "Done connecting to DMX display");
        g_connected_to_dmx = 1;
        /* done with the display after we've got the back-end info */
        XCloseDisplay(dpy);
        return 1;
      }
      else {
        log_write(LL_WARN, "DMXQueryExtension() failed");
      }
      XCloseDisplay(dpy);
    }
    else {
      log_write(LL_WARN, "Unable to open display %s", displayName);
    }
  }
#else
  log_write(LL_DBG, "VNC Proxy compiled without DMX support");
#endif /* USE_DMX */

  /* if we get here, we're not connecting to a DMX (or X) display */

  log_write(LL_MSG, "Connecting to non-DMX display/host");
  parse_displayname(displayName, host, &port);
  hs = connect_to_host(host, displayName, port, x, y, 0);
  if (!hs) {
    log_write(LL_ERROR, "Unable to connect to %s::%d", host, port);
  }

  set_master_host(hs);

  if (opt.frame_sync) {
    sync_group_size(1);
  }

  /* try to connect to any VNC spus running on the host */
  {
    int p;
    for (p = 0; p < NUM_SERVER_PORTS; p++) {
      const int vncSPUport = FIRST_SERVER_PORT + p;
      HOST_SLOT *crhs;
      /* report no errors here */
      crhs = connect_to_host(host, "", vncSPUport, 0, 0, 0);
      if (crhs) {
        crhs->is_vnc_spu = 1;
        crhs->dmx_host = hs;
        sync_add_host(crhs, vncSPUport);
      }
    }
  }

  return hs ? 1 : 0;
}


/**
 * Set the name of the host info file (-H option).
 * Format of file (one line only):
 *   hostname passwd
 * The proxy will connect to the named server with the given password.
 * Only the first 8 chars of the password are significant.
 * \return 1 for success, 0 for failure.
 */
int
connect_to_host_by_file(const char *host_info_file)
{
  if (!parse_host_info(host_info_file)) {
     log_write(LL_ERROR, "Error parsing hostfile %s", host_info_file);
     return 0;
  }

  log_write(LL_INFO, "Connecting to server %s", s_hostname);
  if (!connect_to_display(s_hostname, 0, 0)) {
     log_write(LL_ERROR, "Failed to connect to %s", s_hostname);
     return 0;
  }

  return 1;
}


/*
 * Connect to the hosts listed in the named file.
 * Format of file is:
 *    hostname xpos ypos
 * This is basically a debug function nor ordinarily used.
 */
int
connect_to_hosts(const char *host_info_file)
{
  FILE *fp;

  fp = fopen(host_info_file, "r");
  if (fp == NULL) {
    log_write(LL_ERROR, "Cannot open host info file: %s", host_info_file);
    return 0;
  }

  while (!feof(fp)) {
     char line[1000], dpyName[256];
     int x, y, n;

     if (!fgets(line, sizeof(line), fp))
        break;

     n = sscanf(line, "%s %d %d", dpyName, &x, &y);
     if (n == 1) {
        x = y = 0;
     }
     else if (n != 3) {
        log_write(LL_ERROR, "Bad line in %s: %s", host_info_file, line);
        return 0;
     }

     if (!connect_to_display(dpyName, x, y)) {
        log_write(LL_ERROR, "Failed to connect to %s", dpyName);
     }
  }
  fclose(fp);

  return 1;
}


/**
 * Open the hostinfo file (s_host_info_file) and try to read a hostname
 * and password (on one line, separated by a space).
 * \return 1 if success, 0 if failure.
 */
static int parse_host_info(const char *host_info_file)
{
  FILE *fp;
  char buf[256];
  char *pos, *space_pos;
  int len;

  fp = fopen(host_info_file, "r");
  if (fp == NULL) {
    log_write(LL_ERROR, "Cannot open host info file: %s", host_info_file);
    return 0;
  }

  /* Read the file into a buffer first */
  len = fread(buf, 1, 255, fp);
  buf[len] = '\0';
  fclose(fp);

  if (len == 0) {
    log_write(LL_ERROR, "Error reading host info file (is it empty?)");
    return 0;
  }

  /* Truncate at the end of first line, respecting MS-DOS end-of-lines */
  pos = strchr(buf, '\n');
  if (pos != NULL)
    *pos = '\0';
  pos = strchr(buf, '\r');
  if (pos != NULL)
    *pos = '\0';

  /* FIXME: parsing code below is primitive */

  space_pos = strchr(buf, ' ');
  if (space_pos != NULL) {
    strncpy(s_host_password, space_pos + 1, 9);
    s_host_password[9] = '\0';
    if (strlen(s_host_password) > 8) {
       /* too long of password - it can't be legit */
       s_host_password[0] = 0;
    }
    *space_pos = '\0';
  } else {
    log_write(LL_WARN, "Host password not specified, assuming no auth");
    s_host_password[0] = '\0';
  }

  strcpy(s_hostname, buf);

  log_write(LL_MSG, "Found hostname %s in %s", s_hostname, host_info_file);

  return 1;
}


/* This is called when we first establish a connection to a server host */
static void host_init_hook(void)
{
  cur_slot->type = TYPE_HOST_CONNECTING_SLOT;
  aio_setclose(host_close_hook);
  aio_setread(rf_host_ver, NULL, 12);
}

static void host_listen_init_hook(void)
{
  cur_slot->type = TYPE_HOST_LISTENING_SLOT;
}

static void host_accept_hook(void)
{
  log_write(LL_MSG, "Accepted host connection from %s", cur_slot->name);

  host_init_hook();
}

/*
 * Called by AIO read routine
 */
static void rf_host_ver(void)
{
  char *buf = (char *)cur_slot->readbuf;
  int major = 3, minor = 7/*3*/;
  int remote_major, remote_minor;
  char ver_msg[12];

  if ( strncmp(buf, "RFB ", 4) != 0 || !isdigit(buf[4]) ||
       !isdigit(buf[4]) || !isdigit(buf[5]) || !isdigit(buf[6]) ||
       buf[7] != '.' || !isdigit(buf[8]) || !isdigit(buf[9]) ||
       !isdigit(buf[10]) || buf[11] != '\n' ) {
    log_write(LL_ERROR, "Wrong greeting data received from host");
    aio_close(0);
    return;
  }

  remote_major = atoi(&buf[4]);
  remote_minor = atoi(&buf[8]);
  log_write(LL_INFO, "Remote RFB Protocol version is %d.%d",
            remote_major, remote_minor);

  if (remote_major != major) {
    log_write(LL_ERROR, "Wrong protocol version, expected %d.x", major);
    aio_close(0);
    return;
  } else if (remote_minor != minor) {
    log_write(LL_WARN, "Protocol sub-version does not match (ignoring)");
  }

  sprintf(ver_msg, "RFB %03d.%03d\n", abs(major) % 999, abs(minor) % 999);
  aio_write(NULL, ver_msg, 12);
  if (remote_minor == 3) {
    aio_setread(rf_host_auth, NULL, 4);
  }
  else {
    assert(remote_minor == 7);
    aio_setread(rf_host_security_type_count, NULL, 1);
  }
}

static void rf_host_security_type_count(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  CARD8 nTypes;

  nTypes = buf_get_CARD8(cur_slot->readbuf);
  hs->temp_len = nTypes;
  log_write(LL_DEBUG, "NumSecurityTypes: %d", nTypes);

  aio_setread(rf_host_security_types, NULL, nTypes);
}

static void rf_host_security_types(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  CARD8 *types = cur_slot->readbuf;
  CARD8 authMode;  
  int i;
  int tightSec = 0;

  for (i = 0; i < hs->temp_len; i++) {
    log_write(LL_DEBUG, "Received security type/token 0x%x", types[i]);
    if (types[i] == RFB_AUTH_TIGHT) {
      tightSec = 1;
      break;
    }
  }

  if (!tightSec) {
    log_write(LL_ERROR, "Server does not support 'Tight' security");
    /* XXXX continue with formats() ?? */
    aio_close(0);
    return;
  }

  hs->auth_mode = RFB_AUTH_TIGHT;
  authMode = RFB_AUTH_TIGHT;
  aio_write(NULL, &authMode, sizeof(authMode));

#if 0
  /* get ready for challenge string */
  aio_setread(rf_host_auth_tight, NULL, RFB_CHALLENGE_SIZE);
#endif
  aio_setread(rf_host_num_tunnel_types, NULL, 4);
}

static void rf_host_num_tunnel_types(void)
{
  CARD32 nTypes = buf_get_CARD32(cur_slot->readbuf);
  log_write(LL_DEBUG, "NumTunnelTypes %d", nTypes);
  if (nTypes != 0) {
    log_write(LL_ERROR, "Unexpected number of tunnel types (non-zero)");
    aio_close(1);
  }
  aio_setread(rf_host_num_auths, NULL, 4);
}


/* Receive number of authentication types */
static void rf_host_num_auths(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  hs->temp_len = buf_get_CARD32(cur_slot->readbuf);
  if (hs->temp_len > 0) {
    aio_setread(rf_host_auths, NULL, hs->temp_len * sizeof(CapInfo));
  }
  else {
    log_write(LL_MSG, "No authentication needed");
    send_client_initmsg();
  }
}


/* Receive list of authentication types */
static void rf_host_auths(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  const CapInfo *caps = (const CapInfo *) cur_slot->readbuf;
  int unixAuth = 0, vncAuth = 0;
  int i;

  for (i = 0; i < hs->temp_len; i++) {
    CARD32 auth = Swap32(caps[i].code);
    log_write(LL_DEBUG, "Received security token/type 0x%x", (int) auth);
    if (auth == RFB_AUTH_UNIX) {
      unixAuth = 1;
    }
    else if (auth == RFB_AUTH_VNC) {
      vncAuth = 1;
    }
  }

  if (unixAuth) {
    CARD32 authMode = Swap32(RFB_AUTH_UNIX);
    aio_write(NULL, &authMode, 4);
    log_write(LL_MSG, "Performing Unix login-style authentication");
    send_unix_authentication();
  }
  else if (vncAuth) {
    CARD32 authMode = Swap32(RFB_AUTH_VNC);
    aio_write(NULL, &authMode, 4);
    log_write(LL_MSG, "Performing VNC authentication");
    aio_setread(rf_host_crypt, NULL, 16);
  }
  else {
    /* no authentication */
    aio_setread(rf_host_initmsg, NULL, 24);
  }
}


static void send_unix_authentication(void)
{
  struct passwd *ps;
  char *login, *passwd;
  int loginLen, passwdLen;

  /* Get login name */
#if 0
  if (appData.userLogin) {
    /* login ID from file or cmd line */
    login = appData.userLogin;
  }
  else
#endif
  {
    /* login ID of this process's owner */
    ps = getpwuid(getuid());
    login = ps->pw_name;
  }

  /* get passwd */
  passwd = s_host_password;

  loginLen = Swap32(strlen(login));
  passwdLen = Swap32(strlen(passwd));

  aio_write(NULL, &loginLen, 4);
  aio_write(NULL, &passwdLen, 4);
  aio_write(NULL, login, strlen(login));
  aio_write(NULL, passwd, strlen(passwd));

  /*fprintf(stderr, "Using user name \"%s\", passwd \"%s\"\n", login, passwd);*/

  aio_setread(rf_host_auth_done, NULL, 4);
}

/* get type of authentication required */
static void rf_host_auth(void)
{
  CARD32 value32;

  value32 = buf_get_CARD32(cur_slot->readbuf);

  switch (value32) {
  case 0:
    aio_setread(rf_host_conn_failed_len, NULL, 4);
    break;
  case 1:
    log_write(LL_MSG, "No authentication required at host side");
    send_client_initmsg();
    break;
  case 2:
    log_write(LL_DETAIL, "VNC authentication requested by host");
    aio_setread(rf_host_crypt, NULL, 16);
    break;
  default:
    log_write(LL_ERROR, "Unknown authentication scheme requested by host");
    aio_close(0);
    return;
  }
}

/* get length of connection failure msg */
static void rf_host_conn_failed_len(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  hs->temp_len = buf_get_CARD32(cur_slot->readbuf);
  aio_setread(rf_host_conn_failed, NULL, hs->temp_len);
}

/* get actual connection failure msg */
static void rf_host_conn_failed(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  log_write(LL_ERROR, "VNC connection failed: %.*s",
            (int) hs->temp_len, cur_slot->readbuf);
  aio_close(0);
}

static void rf_host_crypt(void)
{
  unsigned char response[16];

  log_write(LL_DEBUG, "Received random challenge");

  rfb_crypt(response, cur_slot->readbuf, (unsigned char *) s_host_password);
  log_write(LL_DEBUG, "Sending DES-encrypted response");
  aio_write(NULL, response, 16);

  aio_setread(rf_host_auth_done, NULL, 4);
}

/* called after authentication has succeeded */
static void rf_host_auth_done(void)
{
  CARD32 value32;

  value32 = buf_get_CARD32(cur_slot->readbuf);

  switch(value32) {
  case 0:
    log_write(LL_MSG, "VNC Authentication successful");
    send_client_initmsg();
    break;
  case 1:
    log_write(LL_ERROR, "VNC Authentication failed for %s", cur_slot->name);
    aio_close(0);
    break;
  case 2:
    log_write(LL_ERROR, "VNC Authentication failed, too many tries");
    aio_close(0);
    break;
  default:
    log_write(LL_ERROR, "Unknown authentication result");
    aio_close(0);
  }
}

static void send_client_initmsg(void)
{
  CARD8 shared_session = 1;

  log_write(LL_DETAIL, "Requesting %s session",
            (shared_session != 0) ? "non-shared" : "shared");
  aio_write(NULL, &shared_session, 1);

  aio_setread(rf_host_initmsg, NULL, 24);
}

static void rf_host_initmsg(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;

  hs->fb_width = buf_get_CARD16(cur_slot->readbuf);
  hs->fb_height = buf_get_CARD16(&cur_slot->readbuf[2]);
  log_write(LL_MSG, "Remote desktop geometry is %dx%d at %d,%d",
            (int)hs->fb_width, (int)hs->fb_height,
            (int)hs->fb_x_origin, (int)hs->fb_y_origin);

 /* server name string len: */
  hs->temp_len = buf_get_CARD32(&cur_slot->readbuf[20]);
  aio_setread(rf_host_set_formats, NULL, hs->temp_len);
}

static void rf_host_set_formats(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  unsigned char setpixfmt_msg[4 + SZ_RFB_PIXEL_FORMAT];
  unsigned char setenc_msg[32] = {
    RFB_SET_ENCODINGS,          /* Message id */
    0,                          /* Padding -- not used */
    0, 0                        /* Number of encodings */
  };
  int setenc_msg_size;

  /* FIXME: Don't change g_screen_info while there is an active host
     connection! */

  assert(hs->fb_width > 0);
  assert(hs->fb_height > 0);

  log_write(LL_INFO, "Remote desktop name: %.*s",
            (int)hs->temp_len, cur_slot->readbuf);

  if (g_screen_info.name == NULL) {
    static const char *prefix = "VNC Proxy: ";
    const int prefixLen = strlen(prefix);
    g_screen_info.name_length = hs->temp_len + strlen(prefix);
    g_screen_info.name = malloc(g_screen_info.name_length + 1);
    if (g_screen_info.name) {
      memcpy(g_screen_info.name, prefix, prefixLen);
      memcpy(g_screen_info.name + prefixLen, cur_slot->readbuf, hs->temp_len);
      g_screen_info.name[prefixLen + hs->temp_len] = 0;
    }
    else {
      g_screen_info.name_length = 0;
    }
  }

  log_write(LL_DETAIL, "Setting up pixel format");

  memset(setpixfmt_msg, 0, 4);
  setpixfmt_msg[0] = RFB_SET_PIXELFORMAT;
  buf_put_pixfmt(&setpixfmt_msg[4], &g_screen_info.pixformat);
  log_write(LL_DEBUG, "Sending SetPixelFormat message");
  aio_write(NULL, setpixfmt_msg, sizeof(setpixfmt_msg));

  /* build/send encodings info */
  {
    CARD32 encodings[100];
    int num = 0, i;

    /* put preferred encoding first in list */
    if (s_pref_encoding == RFB_ENCODING_TIGHT) {
      log_write(LL_DETAIL, "Requesting Tight encoding");
      encodings[num++] = RFB_ENCODING_TIGHT;
      if (s_tight_level >= 0 && s_tight_level <= 9) {
        log_write(LL_DETAIL, "Requesting compression level %d", s_tight_level);
        encodings[num++] = RFB_ENCODING_COMPRESSLEVEL0 + s_tight_level;
      }
#if 0
      /* we don't request a jpeg quality level since we can't receive
       * jpeg data!  See decode_tight.c
       */
#else
      if (hs->is_vnc_spu) {
        /* only request jpeg encoding from VNC SPUs for now */
        if (opt.jpeg_quality >= 0 && opt.jpeg_quality <= 9) {
          log_write(LL_DETAIL, "Requesting jpeg quality %d", opt.jpeg_quality);
          encodings[num++] = RFB_ENCODING_QUALITYLEVEL0 + opt.jpeg_quality;
        }
      }
#endif
    }
    else if (s_pref_encoding == RFB_ENCODING_HEXTILE) {
      log_write(LL_DETAIL, "Requesting Hextile encoding");
      encodings[num++] = RFB_ENCODING_HEXTILE;
    }
    else if (s_pref_encoding == RFB_ENCODING_RAW) {
      log_write(LL_DETAIL, "Requesting Raw encoding");
      encodings[num++] = RFB_ENCODING_RAW;
    }
    else if (s_pref_encoding == RFB_ENCODING_RAW24) {
      log_write(LL_DETAIL, "Requesting experimental Raw24 encoding");
      encodings[num++] = RFB_ENCODING_RAW24;
    }

    /* other acceptable encodings */
    if (s_pref_encoding != RFB_ENCODING_TIGHT)
       encodings[num++] = RFB_ENCODING_TIGHT;
    if (s_pref_encoding != RFB_ENCODING_HEXTILE)
       encodings[num++] = RFB_ENCODING_HEXTILE;
    if (s_pref_encoding != RFB_ENCODING_RAW)
       encodings[num++] = RFB_ENCODING_RAW;
    if (s_pref_encoding != RFB_ENCODING_RAW24)
       encodings[num++] = RFB_ENCODING_RAW24;
    encodings[num++] = RFB_ENCODING_COPYRECT;
    encodings[num++] = RFB_ENCODING_LASTRECT;
    encodings[num++] = RFB_ENCODING_XCURSOR;
    if (hs->is_vnc_spu) {
      /* some encodings only understood by VNC SPU: */
#if 0
      encodings[num++] = RFB_ENCODING_CLIPRECT;
#endif
      if (opt.half_raw)
        encodings[num++] = RFB_ENCODING_HALF_RAW;
      if (opt.frame_sync) {
        encodings[num++] = RFB_ENCODING_FRAME_SYNC;
      }
    }
    else {
      /* other encodings not understood by VNC SPU: */
      encodings[num++] = RFB_ENCODING_CHROMIUM2;
    }

    /*
    encodings[num++] = RFB_ENCODING_POINTER_POS;
    */
    assert(num <= 100);

    for (i = 0; i < num; i++) {
      buf_put_CARD32(&setenc_msg[4 + 4 * i], encodings[i]);
    }
    buf_put_CARD16(&setenc_msg[2], num);
    setenc_msg_size = 4 + num * 4;
  }
  log_write(LL_DEBUG, "Sending SetEncodings message");
  aio_write(NULL, setenc_msg, setenc_msg_size);

  /* If there was no local framebuffer yet, start listening for client
     connections, assuming we are mostly ready to serve clients. */
  if (g_framebuffer == NULL) {
    AIO_SLOT *slot = aio_listen(s_cl_listen_port, NULL, af_client_accept,
                                sizeof(CL_SLOT));
    if (!slot) {
      log_write(LL_ERROR, "Error creating listening socket: %s",
                strerror(errno));
      log_write(LL_ERROR, "Check that another vncproxy isn't running.");
      aio_close(1);
      return;
    }

    /* initialize the http server */
    http_init(s_cl_listen_port);
  }

  if (hs->auth_mode == RFB_AUTH_TIGHT) {
     aio_setread(rf_host_interaction_caps_len, NULL, 8);
  }
  else {
     /* 'activate' the host indicated by cur_slot */
     host_activate();
  }
}


/* RFB 3.7 */
static void rf_host_interaction_caps_len(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  CARD16 numServerMessageTypes = buf_get_CARD16(cur_slot->readbuf + 0);
  CARD16 numClientMessageTypes = buf_get_CARD16(cur_slot->readbuf + 2);
  CARD16 numEncodingTypes = buf_get_CARD16(cur_slot->readbuf + 4);

  log_write(LL_DEBUG, "NumServerMsgTypes %d\n", numServerMessageTypes);
  log_write(LL_DEBUG, "NumClientMessageTypes %d", numClientMessageTypes);
  log_write(LL_DEBUG, "NumEncodingTypes %d", numEncodingTypes);

  if (numServerMessageTypes != 0 ||
      numClientMessageTypes != 0) {
    log_write(LL_ERROR, "Unexpected number of server/client message types");
    aio_close(1);
    return;
  }

  if (numEncodingTypes > 0) {
    hs->temp_len = numEncodingTypes;
    aio_setread(rf_host_encoding_types, NULL, numEncodingTypes * sizeof(CapInfo));
  }
  else {
    host_activate();
  }
}


/* RFB 3.7: get list of encoding types */
/* Seems to be redundant with prior protocol messages */
static void rf_host_encoding_types(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  const CapInfo *cap = (CapInfo *) cur_slot->readbuf;
  int i;
  for (i = 0; i < hs->temp_len; i++) {
    log_write(LL_DEBUG, "Recevied encoding token 0x%x", Swap32(cap[i].code));
  }
  host_activate();
}



/*
 * Allocate the framebuffer, or extend its size if it exists already.
 */
int alloc_framebuffer(int w, int h)
{
  int fb_size;

  log_write(LL_INFO, "Allocating %d x %d framebuffer", w, h);

  if (g_framebuffer == NULL) {

    /* Just set initial dimentions of the framebuffer. */
    g_fb_width = w;
    g_fb_height = h;

  } else {

    /* Nothing to do if neither width nor height was increased. */
    if (w <= g_fb_width && h <= g_fb_height) {
      log_write(LL_DETAIL, "No need to reallocate framebuffer and cache");
      return 1;
    }

    /* If framebuffer exists, free it's memory first. */
    /* FIXME: Maybe preserve framebuffer contents? */
    log_write(LL_DETAIL, "Freeing the framebuffer");
    free(g_framebuffer);

    /* Framebuffer dimentions may not be decreased. */
    g_fb_width = (w > g_fb_width) ? w : g_fb_width;
    g_fb_height = (h > g_fb_height) ? h : g_fb_height;

  }

  fb_size = (int)g_fb_width * (int)g_fb_height;
  g_framebuffer = malloc(fb_size * sizeof(CARD32));
  if (g_framebuffer == NULL) {
    log_write(LL_ERROR, "Error allocating framebuffer");
    return 0;
  }
  log_write(LL_DETAIL, "(Re)allocated framebuffer, %d bytes",
            fb_size * sizeof(CARD32));

  /* Note: If the cache is already allocated, allocate_enc_cache()
     function frees the cache memory first. */
  if (!allocate_enc_cache()) {
    free(g_framebuffer);
    g_framebuffer = NULL;
    log_write(LL_ERROR, "Error allocating cache for encoded data");
    return 0;
  }
  log_write(LL_DETAIL, "(Re)allocated cache for encoded data, %d bytes",
            sizeof_enc_cache());

  return 1;
}

