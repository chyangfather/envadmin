/**
 * Http server for VNC Proxy.
 *
 * We basically just have to serve some java files to the client/browser.
 * Only implmement the HTTP GET command.
 */


#include <ctype.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#include "rfblib.h"
#include "async_io.h"
#include "logging.h"
#include "translate.h"
#include "client_io.h"
#include "reflector.h"
#include "http.h"


#define DEFAULT_PATH "/usr/share/vnc/classes"

#define NOT_FOUND_STR "HTTP/1.0 404 Not found\r\n\r\n" \
    "<HEAD><TITLE>File Not Found</TITLE></HEAD>\n" \
    "<BODY><H1>File Not Found</H1></BODY>\n"

#define OK_STR "HTTP/1.0 200 OK\r\n\r\n"

#define BUF_SIZE 10000

#define HTTP_PORT 5800


static void http_client_accept(void);
static void http_client_msg(void);
static void process_request(const char *request);

static int ServerPort = 0;

static const char *JavaPath = DEFAULT_PATH;


void
http_init(int serverPort)
{
  AIO_SLOT *slot;

  ServerPort = serverPort;

  slot = aio_listen(HTTP_PORT, NULL, http_client_accept, sizeof(CL_SLOT));
}


void
http_java_path(const char *path)
{
  if (path)
    JavaPath = path;
  else
    JavaPath = DEFAULT_PATH;
}


static void
http_client_accept(void)
{
  CL_SLOT *cl = (CL_SLOT *)cur_slot;
  int i;

  log_write(LL_DEBUG, "Entering http_client_accept");

  cur_slot->type = TYPE_CL_SLOT;
  cl->connected = 0;
  cl->trans_table = NULL;
  aio_setclose(cf_client);

  for (i = 0; i < 4; i++)
    cl->zs_active[i] = 0;

  log_write(LL_MSG, "Accepting http connection from %s", cur_slot->name);

  aio_setread(http_client_msg, NULL, 1);
}


static char message[10000];
static int messageLen = 0;


static void
http_client_msg(void)
{
  /*CL_SLOT *cl = (CL_SLOT *)cur_slot;*/
  char ch = cur_slot->readbuf[0];

  /* accumulate char */
  message[messageLen++] = ch;

  /*
  printf("Got char 0x%x %c\n", (int) ch, (isprint(ch) ? ch : '.'));
  */

  /* see if we've got a full request */
  if (ch == '\n' || ch == '\r') {
     if (strstr(message, "\r\n\r\n")) {
        assert(messageLen > 0);
        message[messageLen-1] = 0;
        if (messageLen > 1)
           process_request(message);
        messageLen = 0;
     }
  }

  /* read next char */
  aio_setread(http_client_msg, NULL, 1);
}


/**
 * If *ptr matches to <varname>, replace <varname> string with <value>,
 * increment ptr and return 1.
 * Else, return 0;
 */
static int
ireplace(char **ptr, const char *varname, int value)
{
  if (strncmp(*ptr, varname, strlen(varname)) == 0) {
    char s[1000];
    sprintf(s, "%d", value);
    aio_write(NULL, s, strlen(s));
    *ptr += strlen(varname);
    return 1;
  }
  return 0;
}


/**
 * As above, but string value, not int.
 */
static int
sreplace(char **ptr, const char *varname, const char *value)
{
  if (strncmp(*ptr, varname, strlen(varname)) == 0) {
    aio_write(NULL, (void *) value, strlen(value));
    *ptr += strlen(varname);
    return 1;
  }
  return 0;
}


/**
 * The only http request we support is file get (GET).
 */
static void
process_request(const char *request)
{
  int doSubstitutions = 0;
  char fname[1000], fullPathname[1000];
  FILE *f;

  log_write(LL_DEBUG, "Servicing http request");

  if (sscanf(request, "GET %s HTTP", fname) != 1) {
    log_write(LL_WARN, "Unexpected http request: %s", request);
    return;
  }

  if (strcmp(fname, "/") == 0) {
    strcpy(fname, "/index.vnc");
  }
  else if (fname[0] != '/') {
    log_write(LL_ERROR, "Requesting illegal file: %s", fname);
    return;
  }

  if (strlen(fname) >= 4 && strcmp(&fname[strlen(fname)-4], ".vnc") == 0) {
    doSubstitutions = 1;
  }

  strcpy(fullPathname, JavaPath);
  strcat(fullPathname, "/");
  strcat(fullPathname, fname);

  f = fopen(fullPathname, "r");
  if (!f) {
    log_write(LL_ERROR, "Unable to open file %s for sending", fullPathname);
    return;
  }

  log_write(LL_INFO, "Sending file by http: %s", fullPathname);

  aio_write(NULL, OK_STR, strlen(OK_STR));

  /* Read the file contents, possibly doing string substitutions for $TOKENS,
   * sending contents to the client.
   * NOTE: this could break if the file size is greater than BUF_SIZE.
   */
  while (1) {
    char buffer[BUF_SIZE], *ptr;
    int n;

    n = fread(buffer, 1, BUF_SIZE, f);
    if (n < 0)
      break;
    if (n == 0)
       break;

    ptr = buffer;

    if (doSubstitutions) {
      char *dollar;
      buffer[n] = 0;

      while ((dollar = strchr(ptr, '$'))) {
        /* write buffer up to $ */

        if (dollar - ptr > 0)
          aio_write(NULL, ptr, dollar - ptr);

        ptr = dollar;
        assert(ptr[0] == '$');

        if (ireplace(&ptr, "$WIDTH", g_fb_width))
          ;
        else if (ireplace(&ptr, "$HEIGHT", g_fb_height))
          ;
        else if (ireplace(&ptr, "$APPLETWIDTH", g_fb_width))
          ;
        else if (ireplace(&ptr, "$APPLETHEIGHT", g_fb_height))
          ;
        else if (ireplace(&ptr, "$PORT", ServerPort))
          ;
        else if (sreplace(&ptr, "$USER", "(username)"))
          ;
        else if (sreplace(&ptr, "$DESKTOP", "VNC Proxy"))
          ;
        else if (sreplace(&ptr, "$DISPLAY", "(displayname)"))
          ;
        else if (sreplace(&ptr, "$PARAMS", "(params)"))
          ;
        else if (ptr[1] == '$') {
          aio_write(NULL, "$$", 2);
          ptr += 2;
        }
        else {
          log_write(LL_ERROR, "Unknown substitution %s in %s", ptr,
                    fullPathname);
          fclose(f);
          return;
        }
      }

      /* send rest of buffer */
      aio_write(NULL, ptr, buffer + n - ptr);
    }
    else {
      /* write buffer as-is, no substitutions */
      aio_write(NULL, buffer, n);
    }
  }
  fclose(f);

  /* XXX need this? */
  aio_write(NULL, "\n\n\n\n", 4);

  aio_flush_output(cur_slot);

  aio_close(0);

  log_write(LL_DEBUG, "Done servicing http request");
}
