
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <zlib.h>

#include "rfblib.h"
#include "reflector.h"
#include "async_io.h"
#include "logging.h"
#include "translate.h"
#include "client_io.h"
#include "host_connect.h"
#include "host_io.h"
#include "barrier.h"


/**
 * Per-window information for barriers
 */
struct window_info {
   int window;
   int curFrame;
   int barrierCount;
   int barrierSize; /* number of rendezvous needed to release the barrier */
   struct window_info *next;
};


/* a linked list suffices since there's few windows. */
static struct window_info *FirstWindow = NULL;


static struct window_info *
lookup_window(int id)
{
   struct window_info *w;

   /* look for existing */
   for (w = FirstWindow; w; w = w->next) {
      if (w->window == id)
         return w;
   }

   /* make new one */
   w = (struct window_info *) calloc(1, sizeof(struct window_info));
   if (w) {
      w->window = id;
      w->barrierSize = get_dmx_num_screens();
      /* insert at head */
      w->next = FirstWindow;
      FirstWindow = w;
   }

   return w;
}


/* aio_walk_slots() callback to suspend the given slot */
static void suspend_cb(AIO_SLOT *s)
{
   s->suspended = SUSPEND_READ | SUSPEND_WRITE;
}

/* aio_walk_slots() callback to resume the given slot */
static void resume_cb(AIO_SLOT *s)
{
   s->suspended = 0;
}


/* resume all host slots with the the given port */
static void
resume_host_slots(int port)
{
   AIO_SLOT *s;
   for (s = aio_first_slot(); s; s = s->next) {
      if (s->type == TYPE_HOST_ACTIVE_SLOT) { /* XXX invalid read on exit - valgrind */
         HOST_SLOT *hs = (HOST_SLOT *) s;
         if (hs->server_port == port) {
            s->suspended = 0;
         }
      }
   }
}


static int NumActiveBarriers = 0;

/**
 * Execute a window barrier
 */
void
window_barrier(int winID, int frameNum)
{
   HOST_SLOT *hs;
   struct window_info *w = lookup_window(winID);
   if (!w)
      return;

   if (w->curFrame == 0) {
      w->curFrame = frameNum;
   }

   if (w->barrierSize < 2) {
      /* only do barrier if there's two more servers to synchronize */
      return;
   }

   assert((cur_slot->suspended & SUSPEND_READ) == 0);
   assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
   hs = (HOST_SLOT *) cur_slot;

   if (w->barrierCount == 0) {
      /* first to rendezvous */
      log_write(LL_INFO, "Begin barrier: win %d (suspend slot %p)",
                winID, (void*) cur_slot);
      /*w->window = winID;*/
      w->curFrame = frameNum;
      w->barrierCount = 1;
      /* XXX suspend client-side sockets */
      aio_walk_slots(suspend_cb, TYPE_CL_SLOT);
      /* suspend this server-side socket */
      assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
      cur_slot->suspended = SUSPEND_READ;
      NumActiveBarriers++;
   }
   else if (w->curFrame == frameNum) {
      /* another rendezvous */
      w->barrierCount++;
      log_write(LL_INFO, "Incr barrier: win %d to %d", winID, w->barrierCount);
      cur_slot->suspended = SUSPEND_READ;
      if (w->barrierCount == w->barrierSize) {
         /* all checked in */
         log_write(LL_INFO, "Release barrier: win %d frame %d", winID, frameNum);
         /* resume all client-side sockets */
         aio_walk_slots(resume_cb, TYPE_CL_SLOT);
         /* resume all server-side sockets */
         resume_host_slots(hs->server_port);
         /* finish up */
         assert(cur_slot->suspended == 0);
         w->barrierCount = 0;
         w->curFrame = 0;
         NumActiveBarriers--;
      }
   }
   else {
      log_write(LL_INFO, "****** Unexpected frame %d from %s (cur frame = %d)",
                frameNum, cur_slot->name, w->curFrame);
   }
}


void
cleanup_barriers(int port)
{
   log_write(LL_INFO, "Cleaning up barriers on port %d", port);
   resume_host_slots(port);
   aio_walk_slots(resume_cb, TYPE_CL_SLOT);

   /* XXX terrible hack! */
   FirstWindow = NULL;
}
