/* VNC Reflector
 * Copyright (C) 2001-2003 HorizonLive.com, Inc.  All rights reserved.
 *
 * This software is released under the terms specified in the file LICENSE,
 * included.  HorizonLive provides e-Learning and collaborative synchronous
 * presentation solutions in a totally Web-based environment.  For more
 * information about HorizonLive, please see our website at
 * http://www.horizonlive.com.
 *
 * This software was authored by Constantin Kaplinsky <const@ce.cctpu.edu.ru>
 * and sponsored by HorizonLive.com, Inc.
 *
 * $Id: host_io.c,v 1.10 2006/10/30 19:32:16 brianp Exp $
 * Asynchronous interaction with VNC host.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <zlib.h>

#include "rfblib.h"
#include "reflector.h"
#include "async_io.h"
#include "logging.h"
#include "translate.h"
#include "client_io.h"
#include "host_connect.h"
#include "host_io.h"
#include "encode.h"
#include "sync.h"
#include "cache.h"
#ifdef NETLOGGER
#include "nl_log.h"
#endif


/**
 * If DIRTY_REGION=1, accumulate dirty/modified rects in a region, then
 * give them to clients en-mass.
 * Otherwise, give dirty/modified rects to clients one at a time as they're
 * processed.
 * The former improves caching.
 */
#define DIRTY_REGION 1

static void host_really_activate(AIO_SLOT *slot);
static void fn_host_pass_newfbsize(AIO_SLOT *slot);

static void rf_host_msg(void);

static void rf_host_fbupdate_hdr(void);
static void rf_host_fbupdate_recthdr(void);
static void rf_host_fbupdate_raw(void);
static void rf_host_fbupdate_raw24(void);
static void rf_host_fbupdate_raw24hdr(void);
static void rf_host_fbupdate_halfraw(void);
static void rf_host_copyrect(void);
static void rf_host_frame_sync(void);

static void fn_host_add_client_rect(AIO_SLOT *slot);
static void fn_host_add_client_region(AIO_SLOT *slot);

static void rf_host_colormap_hdr(void);
static void rf_host_colormap_data(void);

static void rf_host_cuttext_hdr(void);
static void rf_host_cuttext_data(void);
static void fn_host_pass_cuttext(AIO_SLOT *slot);

static void rf_host_xcursor(void);
static void rf_host_pointer_pos(int x, int y);
static void rf_host_chromium_start(void);

static void reset_framebuffer(void);
static void request_update(int incr);
static void fbupdate_done(HOST_SLOT *hs);


/*
 * Implementation
 */

static HOST_SLOT *s_master_host_slot = NULL; /* XXX the DMX server! */
static AIO_SLOT *s_new_slot = NULL;

/* Prepare host I/O slot for operating in main protocol phase */
void host_activate(void)
{
#if 0
  if (s_master_host_slot == NULL) {
    /* Just activate */
    host_really_activate(cur_slot);
  } else {
    /* Let close hook do the work */
    s_new_slot = cur_slot;
    aio_close_other(s_master_host_slot, 0);
  }
#else
  host_really_activate(cur_slot);
#endif
}

/* On-close hook */
void host_close_hook(void)
{

  if (cur_slot->type == TYPE_HOST_ACTIVE_SLOT) {
    HOST_SLOT *hs = (HOST_SLOT *) cur_slot;

    sync_remove_host(hs);

    /* Close session file if open  */
    fbs_close_file();

    /* Erase framebuffer contents, invalidate cache */
    /* FIXME: Don't reset if there is a new connection, so the
       framebuffer (of its new size) would be changed anyway? */
    reset_framebuffer();

    if (cur_slot == (AIO_SLOT *) s_master_host_slot)
       s_master_host_slot = NULL;
  }

  if (cur_slot->errread_f) {
    if (cur_slot->io_errno) {
      log_write(LL_ERROR, "Host I/O error, read: %s",
                strerror(cur_slot->io_errno));
    } else {
      log_write(LL_ERROR, "Host I/O error, read");
    }
  } else if (cur_slot->errwrite_f) {
    if (cur_slot->io_errno) {
      log_write(LL_ERROR, "Host I/O error, write: %s",
                strerror(cur_slot->io_errno));
    } else {
      log_write(LL_ERROR, "Host I/O error, write");
    }
  } else if (cur_slot->errio_f) {
    log_write(LL_ERROR, "Host I/O error");
  }

  if (s_new_slot == NULL) {
    log_write(LL_WARN, "Closing connection to host %s", cur_slot->name);
    /* Exit event loop if framebuffer does not exist yet. */
    if (g_framebuffer == NULL)
      aio_close(1);
    remove_active_file();
    if (s_new_slot == (AIO_SLOT *) s_master_host_slot) {
      log_write(LL_WARN, "Exiting");
      exit(0);
    }
  } else {
    log_write(LL_INFO, "Closing previous connection to host %s", s_new_slot->name);
    host_really_activate(s_new_slot);
    s_new_slot = NULL;
  }
}


/**
 * This is the host we'll send mouse and keyboard events to when using DMX.
 */
void set_master_host(HOST_SLOT *hs)
{
  assert(!s_master_host_slot);
  s_master_host_slot = hs;
}


static void host_really_activate(AIO_SLOT *slot)
{
  AIO_SLOT *saved_slot = cur_slot;
  HOST_SLOT *hs = (HOST_SLOT *)slot;

  log_write(LL_MSG, "Activating new host connection");
  slot->type = TYPE_HOST_ACTIVE_SLOT;

  write_active_file();
  perform_action("host_activate");

  /* Allocate the framebuffer or extend its dimensions if necessary */
  {
    int xmax = hs->fb_width + hs->fb_x_origin;
    int ymax = hs->fb_height + hs->fb_y_origin;
    if (xmax > g_screen_info.width)
      g_screen_info.width = xmax;
    if (ymax > g_screen_info.height)
      g_screen_info.height = ymax;
    if (!alloc_framebuffer(g_screen_info.width, g_screen_info.height)) {
      aio_close(1);
      return;
    }
  }

  /* If requested, open file to save this session and write the header */
  fbs_open_file(hs->fb_width, hs->fb_height);

  cur_slot = slot;

  /* Reset zlib streams in the Tight decoder */
  reset_tight_streams();

  /* Request initial screen contents */
  if (!hs->is_input_only) {
    log_write(LL_DETAIL, "Requesting full framebuffer update");
    request_update(0);
    request_update(1);
  }
  aio_setread(rf_host_msg, NULL, 1);

  /* Notify clients about desktop geometry change */
  aio_walk_slots(fn_host_pass_newfbsize, TYPE_CL_SLOT);

  cur_slot = saved_slot;
}

/*
 * Inform a client about new desktop geometry.
 */

static void fn_host_pass_newfbsize(AIO_SLOT *slot)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  FB_RECT r;

  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  r.enc = RFB_ENCODING_NEWFBSIZE;
  r.x = r.y = 0;
  r.w = hs->fb_width;
  r.h = hs->fb_height;
  fn_client_add_rect(slot, &r);
}

/***************************/
/* Processing RFB messages */
/***************************/

static void rf_host_msg(void)
{
  int msg_id;

  msg_id = (int)cur_slot->readbuf[0] & 0xFF;

  switch(msg_id) {
  case RFB_FRAMEBUFFER_UPDATE:
    aio_setread(rf_host_fbupdate_hdr, NULL, 3);
    break;
  case RFB_SET_COLORMAP_ENTRIES:
    aio_setread(rf_host_colormap_hdr, NULL, 5);
    break;
  case RFB_BELL:
    log_write(LL_DETAIL, "Received Bell message from host");
    fbs_write_data(cur_slot->readbuf, 1);
    aio_setread(rf_host_msg, NULL, 1);
    break;
  case RFB_SERVER_CUT_TEXT:
    aio_setread(rf_host_cuttext_hdr, NULL, 7);
    break;
  case RFB_CHROMIUM_START:
    /* When a new Cr app starts, we'll get this message from each VNC SPU */
    aio_setread(rf_host_chromium_start, NULL, SIZE_RFB_CHROMIUM_START_MSG - 1);
    break;
  default:
    log_write(LL_ERROR, "Unknown server message type: %d from %s", msg_id, cur_slot->name);
    aio_setread(rf_host_msg, NULL, 1);
    /*
    aio_close(0);
    */
  }
}


/**
 * Called when a Chromium-Start messages is received from the VNC Server
 * Indicates another OpenGL app has started.  Connect to the app's VNC SPUs
 * at this time.
 */
static void rf_host_chromium_start(void)
{
  const char *host = cur_slot->name;
  const char *dpyName = cur_slot->dpy_name;
#if 0
  /* if protocol is big endian */
  int serverPort = buf_get_CARD32(&cur_slot->readbuf[3]);
  int mothershipPort = buf_get_CARD32(&cur_slot->readbuf[7]);
#else
  /* if protocol is little endian */
  /* XXX fix this in vnc extension someday */
  int serverPort = *((int *) (cur_slot->readbuf + 3));
  int mothershipPort = *((int *) (cur_slot->readbuf + 7));
#endif
  int xoffset = 0, yoffset = 0;
  HOST_SLOT *hs;

  log_write(LL_INFO, "Got ChromiumStart message");
  log_write(LL_INFO, "Connecting to host %s on port %d (ms %d)",
            host, serverPort, mothershipPort);

  /* Need to determine if the host we're connecting to is a DMX back-end.
   * If so, need to know this host's screen position within the mural
   * to set the xoffset/yoffset values correctly.
   */
  assert(dpyName);
#if USE_DMX
  if (g_connected_to_dmx &&
      !get_dmx_screen_position(dpyName, &xoffset, &yoffset)) {
    log_write(LL_WARN,
              "Couldn't get position of display %s in DMX mural", dpyName);
  }
#endif

  hs = connect_to_host(host, dpyName, serverPort, xoffset, yoffset, 0);
  if (!hs) {
    log_write(LL_ERROR,
              "Unable to connect to new VNC SPU at %s:%d", host, serverPort);
    return;
  }
  else {
    assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
    hs->dmx_host = (HOST_SLOT *) cur_slot;
    hs->is_vnc_spu = 1;
    hs->server_port = serverPort;
    assert(hs->s.name);
    sync_add_host(hs, serverPort);
  }
  aio_setread(rf_host_msg, NULL, 1);
}


/********************************/
/* Handling framebuffer updates */
/********************************/

static double get_time(void)
{
   struct timeval tv;
   struct timezone tz;
   (void) gettimeofday(&tv, &tz);
   return (double) tv.tv_sec + tv.tv_usec / 1000000.0;
}


static void
compute_fps(const FB_RECT *rect, const HOST_SLOT *hs)
{
#if DEBUG_FPS
  static const HOST_SLOT *prev_hs = NULL;
#endif
  const float minPeriod = 10.0; /* seconds */
  static int updates = 0;
  const int fpsX = g_fb_width / 2;
  const int fpsY = g_fb_height / 2;
  static double t0 = -1.0;

  if (rect->x <= fpsX && fpsX < rect->x + rect->w &&
      rect->y <= fpsY && fpsY < rect->y + rect->h) {

#if DEBUG_FPS
    {
       static int totalUpdates = 0;
       totalUpdates++;

       if (totalUpdates % 20 == 0)
          printf("Total updates received: %d\n", totalUpdates);

       if (prev_hs == NULL)
          prev_hs = hs;
       else if (prev_hs != hs)
          fprintf(stderr,
                  "VNC Proxy: compute_fps() different hosts: %s vs. %s\n",
                  prev_hs->s.name, hs->s.name);
       prev_hs = hs;
    }
#endif

    updates++;
    if (t0 < 0.0) {
      t0 = get_time();
    }
    else {
      double t1 = get_time();
      if (t1 - t0 >= minPeriod) {
        double rate = updates / (t1 - t0);
        log_write(LL_MSG, "recv updates/second at (%d, %d): %f (%d during %.2fs)", fpsX, fpsY, rate, updates, t1-t0);
#ifdef NETLOGGER
        NL_info("vncproxy", "proxy.updates_per_sec", "RATE=d", rate);
#endif
        updates = 0;
        t0 = t1;
      }
    }
  }
}


/**
 * Called when we receive an RFB_FRAMEBUFFER_UPDATE message.
 * Depending on the encoding, call aio_setread() to process the message body.
 */
static void rf_host_fbupdate_hdr(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  CARD8 hdr_buf[4];
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  assert(!hs->is_input_only);

  hs->rect_count = buf_get_CARD16(&cur_slot->readbuf[1]);

#ifdef NETLOGGER
  if (hs->is_vnc_spu) {
    NL_info("vncproxy", "proxy.fbupdate.receive.begin",
            "NODE=s NUMBER=i NUMRECTS=i",
            hs->s.name, hs->serial_number, hs->rect_count);
    hs->rcv_serial_number = hs->serial_number;
  }
#endif

  /*
  printf("got VNC fbupdate from %p, VNC %d, %d rects\n",
         (void*) hs, hs->is_vnc_spu, hs->rect_count);
  */

  if (hs->rect_count == 0xFFFF) {
    log_write(LL_DETAIL, "Receiving framebuffer update from %s (w/ LastRect)", cur_slot->name);
  } else {
    log_write(LL_DETAIL, "Receiving framebuffer update from %s (%d rects)",
              cur_slot->name, hs->rect_count);
  }

  hdr_buf[0] = 0;
  memcpy(&hdr_buf[1], cur_slot->readbuf, 3);
  fbs_spool_data(hdr_buf, 4);

  if (hs->rect_count) {
     /* We would normally wait until the end of an RFB update message before
      * requesting the next one, but doing it here gets the request to the
      * VNC SPUs faster so that the next frame arrives with less latency.
      */
    request_update(1);

    begin_caching(hs);
    sync_begin_recv_update(hs);
    /* Note: end_caching() will be called in fbupdate_rect_done() */
    aio_setread(rf_host_fbupdate_recthdr, NULL, 12);
  }
  else {
    log_write(LL_DEBUG, "Requesting incremental framebuffer update");
    request_update(1);
    aio_setread(rf_host_msg, NULL, 1);
  }
}


/**
 * Called prior to receiving each fbupdate rect.
 */
static void rf_host_fbupdate_recthdr(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);

  hs->cur_rect.x = buf_get_CARD16(cur_slot->readbuf);
  hs->cur_rect.y = buf_get_CARD16(&cur_slot->readbuf[2]);
  hs->cur_rect.w = buf_get_CARD16(&cur_slot->readbuf[4]);
  hs->cur_rect.h = buf_get_CARD16(&cur_slot->readbuf[6]);
  hs->cur_rect.enc = buf_get_CARD32(&cur_slot->readbuf[8]);

  fbs_spool_data(cur_slot->readbuf, 12);

  log_write(LL_DEBUG, "Receiving rect %dx%d at %d,%d encoding=%s",
            (int)hs->cur_rect.w, (int)hs->cur_rect.h,
            (int)hs->cur_rect.x, (int)hs->cur_rect.y,
            rfb_encoding_name(hs->cur_rect.enc));

  /* Bias for DMX */
  hs->cur_rect.x += hs->fb_x_origin;
  hs->cur_rect.y += hs->fb_y_origin;
  cache_rect(hs, &hs->cur_rect);

  /* Handle special encodings first */
  if (hs->cur_rect.enc == RFB_ENCODING_LASTRECT) {
    log_write(LL_DEBUG, "LastRect marker received from the host");
    hs->cur_rect.x = hs->cur_rect.y = 0;
    hs->rect_count = 1;
    fbupdate_rect_done();
    return;
  }
  else if (hs->cur_rect.enc == RFB_ENCODING_XCURSOR) {
    log_write(LL_DEBUG, "Receiving XCursor pseudo-encoding from %s",
              hs->s.name);
    /* Need to undo DMX bias here */
    hs->cur_rect.x -= hs->fb_x_origin;
    hs->cur_rect.y -= hs->fb_y_origin;
    if (hs->cur_rect.w == 0 && hs->cur_rect.h == 0) {
      log_write(LL_DEBUG, "NULL cursor!");
      fbupdate_rect_done();
    }
    else {
      aio_setread(rf_host_xcursor, NULL, SIZE_RFB_XCURSOR_COLORS_MSG);
    }
    return;
  }
  else if (hs->cur_rect.enc == RFB_ENCODING_POINTER_POS) {
    log_write(LL_DEBUG, "Receiving Pointer Pos pseudo-encoding (%d, %d)",
              hs->cur_rect.x, hs->cur_rect.y);
    rf_host_pointer_pos(hs->cur_rect.x, hs->cur_rect.y);
    fbupdate_rect_done();
    return;
  }
  else if (hs->cur_rect.enc == RFB_ENCODING_FRAME_SYNC) {
     /*log_write(LL_DEBUG, "Frame Sync received from the host");*/
    aio_setread(rf_host_frame_sync, NULL, 8);
    return;
  }

  /* Ignore zero-size rectangles */
  if (hs->cur_rect.h == 0 || hs->cur_rect.w == 0) {
    log_write(LL_WARN, "Zero-size rectangle %dx%d at %d,%d (ignoring)",
              (int)hs->cur_rect.w, (int)hs->cur_rect.h,
              (int)hs->cur_rect.x, (int)hs->cur_rect.y);
    fbupdate_rect_done();
    return;
  }

  /* Handle NewFBSize "encoding", as a special case */
  if (hs->cur_rect.enc == RFB_ENCODING_NEWFBSIZE) {
    log_write(LL_INFO, "New host desktop geometry: %dx%d",
              (int)hs->cur_rect.w, (int)hs->cur_rect.h);
    g_screen_info.width = hs->fb_width = hs->cur_rect.w;
    g_screen_info.height = hs->fb_height = hs->cur_rect.h;

    /* Reallocate the framebuffer if necessary */
    if (!alloc_framebuffer(g_screen_info.width, g_screen_info.height)) {
      aio_close(1);
      return;
    }

    hs->cur_rect.x = hs->cur_rect.y = 0;

    /* NewFBSize is always the last rectangle regardless of rect_count */
    hs->rect_count = 1;
    fbupdate_rect_done();
    return;
  }
  else if (hs->cur_rect.enc == RFB_ENCODING_CLIPRECT) {
    int x, y, w, h;
    printf("New cliprects:      %d, %d  %d x %d\n",
         hs->cur_rect.x, hs->cur_rect.y, hs->cur_rect.w, hs->cur_rect.h);
    x = hs->cur_rect.x - 100 - hs->fb_x_origin;
    y = hs->cur_rect.y - 100 - hs->fb_y_origin;
    if (x < 0)
      x = 0;
    if (y < 0)
      y = 0;
    w = hs->cur_rect.w + 200;
    h = hs->cur_rect.h + 200;

    hs->rect_count = 1;
#if 1
    printf("Request update for: %d, %d  %d x %d from XVNC on %s\n",
         x, y, w, h, hs->s.name);
    /* find hs here! */
    assert(hs->dmx_host);
    request_update_rect(hs->dmx_host, 0, x, y, w, h);
#endif
    fbupdate_rect_done();
    return;
  }

  /* Prevent overflow of the framebuffer */
  if (hs->cur_rect.x >= g_fb_width
      || hs->cur_rect.x + hs->cur_rect.w > g_fb_width
      || hs->cur_rect.y >= g_fb_height
      || hs->cur_rect.y + hs->cur_rect.h > g_fb_height) {
    log_write(LL_ERROR, "Rectangle out of framebuffer bounds: %dx%d at %d,%d",
              (int)hs->cur_rect.w, (int)hs->cur_rect.h,
              (int)hs->cur_rect.x, (int)hs->cur_rect.y);
    aio_close(0);
    return;
  }

  /* Ok, now the rectangle seems correct */

  /* check if rect contains the FPS pixel */
  compute_fps(&hs->cur_rect, hs);

  switch(hs->cur_rect.enc) {
  case RFB_ENCODING_RAW:
    log_write(LL_DEBUG, "Receiving raw data, expecting %d byte(s)",
              hs->cur_rect.w * hs->cur_rect.h * sizeof(CARD32));
    hs->rect_cur_row = 0;
    aio_setread(rf_host_fbupdate_raw,
                &g_framebuffer[hs->cur_rect.y * (int)g_fb_width +
                               hs->cur_rect.x],
                hs->cur_rect.w * sizeof(CARD32));
    break;
  case RFB_ENCODING_COPYRECT:
    log_write(LL_DEBUG, "Receiving CopyRect instruction");
    aio_setread(rf_host_copyrect, NULL, 4);
    break;
  case RFB_ENCODING_HEXTILE:
    log_write(LL_DEBUG, "Receiving Hextile-encoded data");
    setread_decode_hextile(&hs->cur_rect);
    break;
  case RFB_ENCODING_TIGHT:
    log_write(LL_DEBUG, "Receiving Tight-encoded data");
    setread_decode_tight(&hs->cur_rect);
    break;
  case RFB_ENCODING_RAW24:
    log_write(LL_DEBUG, "Receiving Raw24 data");
    hs->rect_cur_row = 0;
    aio_setread(rf_host_fbupdate_raw24hdr, NULL, 4);
    break;
  case RFB_ENCODING_HALF_RAW:
    log_write(LL_DEBUG, "Receiving half-rez raw data");
    hs->rect_cur_row = 0;
    aio_setread(rf_host_fbupdate_halfraw, NULL, hs->cur_rect.w * 4);
    break;
  default:
    log_write(LL_ERROR, "Unknown encoding: 0x%08lX",
              (unsigned long)hs->cur_rect.enc);
    aio_close(0);
  }
}

#if 0
static void print_bitmap(int w, int h, unsigned char *b)
{
   int i, j;
   for (i = 0; i < h; i++) {
      int bit = 128;
      for (j = 0; j < w; j++) {
         if (*b & bit)
            printf("1");
         else
            printf(".");
         bit = bit >> 1;
         if (bit == 0) {
            bit = 128;
            b++;
         }
      }
      if (bit != 128) {
         b++;
         bit = 128;
      }
      printf("\n");
   }
}
#endif


static RFB_XCURSOR_INFO xcursor;

/* Callback called by the aio_walk_slots() function.
 * Update the client's xcursor info.
 */
static void fn_client_add_xcursor(AIO_SLOT *slot)
{
  CL_SLOT *cl = (CL_SLOT *)slot;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);

  if (cl->enable_xcursor) {
    cl->xcursor = &xcursor;
    cl->new_xcursor = 1;
  }
}

/*
 * Called after the xcursor bitmap has been read.
 */
static void rf_host_xcursor_data(void)
{
  int bytesData = ((xcursor.rect.w + 7) / 8) * xcursor.rect.h;

  /* save cursor bitmap data */
  memcpy(xcursor.bitmap_data, cur_slot->readbuf, bytesData * 2);

  /* Update all clients with the new cursor info */
  aio_walk_slots(fn_client_add_xcursor, TYPE_CL_SLOT);
#if 0
  printf("Received xcursor data %d x %d\n", xcursor.rect.w, xcursor.rect.h);
  print_bitmap(xcursor.rect.w, xcursor.rect.h, cur_slot->readbuf);
  printf("\n");
  print_bitmap(xcursor.rect.w, xcursor.rect.h, cur_slot->readbuf + bytesData);
#endif

  /* Done with this rectangle update (a pseudo-encoding) */
  fbupdate_rect_done();
}

/**
 * Called in response to an RFB_ENCODING_XCURSOR pseudo-encoding rectangle.
 */
static void rf_host_xcursor(void)
{
  int bytesData;

  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);

  assert(hs->cur_rect.enc == RFB_ENCODING_XCURSOR);
  xcursor.rect.x = hs->cur_rect.x;
  xcursor.rect.y = hs->cur_rect.y;
  xcursor.rect.w = hs->cur_rect.w;
  xcursor.rect.h = hs->cur_rect.h;
  xcursor.rect.enc = RFB_ENCODING_XCURSOR;
  xcursor.fore_red = cur_slot->readbuf[0];
  xcursor.fore_green = cur_slot->readbuf[1];
  xcursor.fore_blue = cur_slot->readbuf[2];
  xcursor.back_red = cur_slot->readbuf[3];
  xcursor.back_green = cur_slot->readbuf[4];
  xcursor.back_blue = cur_slot->readbuf[5];

  /* max cursor size is 64x64 pixels for now */
  assert(xcursor.rect.w <= 64);
  assert(xcursor.rect.h <= 64);

  bytesData = ((xcursor.rect.w + 7) / 8) * xcursor.rect.h;

  /*
  printf("Cursor colors: fore: %d %d %d\n",
         cur_slot->readbuf[0], cur_slot->readbuf[1], cur_slot->readbuf[2]);
  printf("Cursor colors: back: %d %d %d\n",
         cur_slot->readbuf[3], cur_slot->readbuf[4], cur_slot->readbuf[5]);
  */

  if (bytesData > 0) {
    /* read two bitmaps (foreground and background bitmaps) */
    aio_setread(rf_host_xcursor_data, NULL, bytesData * 2);
  }
  else {
    fbupdate_rect_done();
  }
}


static int xpos, ypos;

static void fn_client_add_pointer_pos(AIO_SLOT *slot)
{
  CL_SLOT *cl = (CL_SLOT *)slot;
  if (cl->enable_xcursor) {
    cl->pointer_x = xpos;
    cl->pointer_y = ypos;
    cl->new_pointer_pos = 1;
  }
}

static void rf_host_pointer_pos(int x, int y)
{
  xpos = x;
  ypos = y;
  /* Update all clients with the new cursor info */
  aio_walk_slots(fn_client_add_pointer_pos, TYPE_CL_SLOT);
}


static void rf_host_fbupdate_raw(void)
{
  int idx;
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);

  fbs_spool_data(cur_slot->readbuf, hs->cur_rect.w * sizeof(CARD32));

  if (++hs->rect_cur_row < hs->cur_rect.h) {
    /* Read next row */
    idx = (hs->cur_rect.y + hs->rect_cur_row) * (int)g_fb_width + hs->cur_rect.x;
    aio_setread(rf_host_fbupdate_raw, &g_framebuffer[idx],
                hs->cur_rect.w * sizeof(CARD32));
  } else {
    /* Done with this rectangle */
    fbupdate_rect_done();
  }
}


static void rf_host_fbupdate_raw24hdr(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  /*CARD32 serialNumber = buf_get_CARD32(cur_slot->readbuf);*/
  aio_setread(rf_host_fbupdate_raw24, NULL, hs->cur_rect.w * 3); /* one line */
}


static void rf_host_fbupdate_raw24(void)
{
  int i;
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  CARD8 *src = cur_slot->readbuf;
  CARD32 *dest;

  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  assert(hs->rect_cur_row < hs->cur_rect.h);

  fbs_spool_data(cur_slot->readbuf, hs->cur_rect.w * 3);

  /* store this row */
  dest = (CARD32 *) g_framebuffer
     + (hs->cur_rect.y + hs->rect_cur_row) * (int)g_fb_width + hs->cur_rect.x;
  for (i = 0; i < hs->cur_rect.w; i++) {
     dest[i] = (src[0]) | (src[1] << 8) | (src[2] << 16);
     src += 3;
  }

  hs->rect_cur_row++;

  if (hs->rect_cur_row < hs->cur_rect.h) {
    /* Read next row */
    aio_setread(rf_host_fbupdate_raw24, NULL, hs->cur_rect.w * 3);
  } else {
    /* Done with this rectangle */
    fbupdate_rect_done();
  }
}


static void rf_host_fbupdate_halfraw(void)
{
  int i;
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  CARD32 *src = (CARD32 *) cur_slot->readbuf;
  CARD32 *dest1, *dest2;

  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  assert(hs->rect_cur_row < hs->cur_rect.h);

  fbs_spool_data(cur_slot->readbuf, hs->cur_rect.w * 4);

  /* store this row */
  dest1 = (CARD32 *) g_framebuffer
     + (hs->cur_rect.y + hs->rect_cur_row * 2) * (int)g_fb_width + hs->cur_rect.x;
  dest2 = dest1 + g_fb_width;

  for (i = 0; i < hs->cur_rect.w; i++) {
     dest1[i * 2 + 0] =
     dest1[i * 2 + 1] =
     dest2[i * 2 + 0] = 
     dest2[i * 2 + 1] = src[i];
  }

  hs->rect_cur_row++;

  if (hs->rect_cur_row < hs->cur_rect.h) {
    /* Read next row */
    aio_setread(rf_host_fbupdate_halfraw, NULL, hs->cur_rect.w * 4);
  } else {
    /* Done with this rectangle */
    hs->cur_rect.w *= 2;
    hs->cur_rect.h *= 2;
    fbupdate_rect_done();
  }
}


static void rf_host_copyrect(void)
{
  CARD32 *src_ptr;
  CARD32 *dst_ptr;
  int width = (int)g_fb_width;
  int row;
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);

  fbs_spool_data(cur_slot->readbuf, 4);

  hs->cur_rect.src_x = buf_get_CARD16(cur_slot->readbuf);
  hs->cur_rect.src_y = buf_get_CARD16(&cur_slot->readbuf[2]);

  /* Apply the DMX screen bias */
  hs->cur_rect.src_x += hs->fb_x_origin;
  hs->cur_rect.src_y += hs->fb_y_origin;

  if ( hs->cur_rect.src_x >= g_fb_width ||
       hs->cur_rect.src_x + hs->cur_rect.w > g_fb_width ||
       hs->cur_rect.src_y >= g_fb_height ||
       hs->cur_rect.src_y + hs->cur_rect.h > g_fb_height ) {
    log_write(LL_ERROR,
              "CopyRect from outside of the framebuffer: %dx%d from %d,%d",
              (int)hs->cur_rect.w, (int)hs->cur_rect.h,
              (int)hs->cur_rect.src_x, (int)hs->cur_rect.src_y);
    aio_close(0);
    return;
  }

  if (hs->cur_rect.src_y > hs->cur_rect.y) {
    /* Copy rows starting from top */
    src_ptr = &g_framebuffer[hs->cur_rect.src_y * width + hs->cur_rect.src_x];
    dst_ptr = &g_framebuffer[hs->cur_rect.y * width + hs->cur_rect.x];
    for (row = 0; row < hs->cur_rect.h; row++) {
      memmove(dst_ptr, src_ptr, hs->cur_rect.w * sizeof(CARD32));
      src_ptr += width;
      dst_ptr += width;
    }
  } else {
    /* Copy rows starting from bottom */
    src_ptr = &g_framebuffer[(hs->cur_rect.src_y + hs->cur_rect.h - 1) * width +
                             hs->cur_rect.src_x];
    dst_ptr = &g_framebuffer[(hs->cur_rect.y + hs->cur_rect.h - 1) * width +
                             hs->cur_rect.x];
    for (row = 0; row < hs->cur_rect.h; row++) {
      memmove(dst_ptr, src_ptr, hs->cur_rect.w * sizeof(CARD32));
      src_ptr -= width;
      dst_ptr -= width;
    }
  }

  fbupdate_rect_done();
}


/**
 * Receive/process a frame sync message.
 * XXX this doesn't really do anything - will probably go away.
 */
static void rf_host_frame_sync(void)
{
  int frame, win;
  fbs_spool_data(cur_slot->readbuf, 8);

  win = buf_get_CARD32(cur_slot->readbuf);
  frame = buf_get_CARD32(cur_slot->readbuf + 4);
  log_write(LL_INFO, "Received frame sync win %d frame %d from %s",
            win, frame, cur_slot->name);

  fbupdate_rect_done();

  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  /* Use the server port number to make the window ID unique.
   * Otherwise, we may get two different GL apps with the same window ID.
   */
  {
    HOST_SLOT *hs = (HOST_SLOT *) cur_slot;
    assert(hs->is_vnc_spu);
    win = (hs->server_port << 16) | win;
  }
}



/********************************/
/* Functions called by decoders */
/********************************/

/*
 * In the framebuffer, fill a rectangle with a specified color.
 */

void fill_fb_rect(FB_RECT *r, CARD32 color)
{
  int x, y;
  CARD32 *fb_ptr = &g_framebuffer[r->y * (int)g_fb_width + r->x];

  for (y = 0; y < r->h; y++) {
    for (x = 0; x < r->w; x++) {
      fb_ptr[x] = color;
    }
    fb_ptr += g_fb_width;
  }
}


/**
 * This function is called by decoders after each rectangle
 * has been successfully decoded.
 * If the update consists of several rects, this'll be called after each.
 */
void fbupdate_rect_done(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  assert(!hs->is_input_only);

  /* check the rectangle encoding here to be sure it's not a pseudo-enc */
  if (hs->cur_rect.enc != RFB_ENCODING_XCURSOR &&
      hs->cur_rect.enc != RFB_ENCODING_POINTER_POS &&
      hs->cur_rect.enc != RFB_ENCODING_LASTRECT &&
      hs->cur_rect.enc != RFB_ENCODING_CLIPRECT &&
      hs->cur_rect.w != 0 && hs->cur_rect.h != 0) {

#if DIRTY_REGION
    /* Add this rect to the host region */
    {
      BoxRec b;
      RegionRec reg;
      b.x1 = hs->cur_rect.x;
      b.y1 = hs->cur_rect.y;
      b.x2 = b.x1 + hs->cur_rect.w;
      b.y2 = b.y1 + hs->cur_rect.h;
      REGION_INIT(&reg, &b, 1);
      REGION_UNION(&hs->region, &hs->region, &reg);
    }
#else
    /* Queue this rectangle for each client */
    aio_walk_slots(fn_host_add_client_rect, TYPE_CL_SLOT);
#endif

    /* Cached data for this rectangle is not valid any more */
    invalidate_enc_cache(&hs->cur_rect);

    /* Save data in a file if necessary */
    fbs_flush_data();
  }

#ifdef NETLOGGER_foo
  if (hs->is_vnc_spu) {
    NL_info("vncproxy", "proxy.fbupdate.receive.rect",
            "NODE=s NUMBER=i RECT=i",
            hs->s.name, hs->rcv_serial_number, hs->rect_count);
  }
#endif

  if (--hs->rect_count) {
    /* another rect is expected */
    aio_setread(rf_host_fbupdate_recthdr, NULL, 12);
  } else {
    /* all done with RFB update message */
    fbupdate_done(hs);
  }
}


/* XXX temporary */
HOST_SLOT *sending_host = NULL;

/**
 * Called after the last rect in an RFB update message has been processed.
 */
static void fbupdate_done(HOST_SLOT *hs)
{
#if DIRTY_REGION
  /* inform each of the clients of the newly changed region from this host */
  aio_walk_slots(fn_host_add_client_region, TYPE_CL_SLOT);
  REGION_EMPTY(&hs->region); /* reset to empty */
#endif

  end_caching(hs);

  sync_end_recv_update(hs);

  sending_host = hs;
  aio_walk_slots(fn_client_send_rects, TYPE_CL_SLOT);
  sending_host = NULL;

  log_write(LL_DEBUG, "Requesting incremental framebuffer update");

  request_update(1);
  aio_setread(rf_host_msg, NULL, 1);

#ifdef NETLOGGER
  if (hs->is_vnc_spu) {
    NL_info("vncproxy", "proxy.fbupdate.receive.end",
            "NODE=s NUMBER=i", hs->s.name, hs->rcv_serial_number);
  }
#endif
}


static void fn_host_add_client_rect(AIO_SLOT *slot)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  fn_client_add_rect(slot, &hs->cur_rect);
}

static void fn_host_add_client_region(AIO_SLOT *slot)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  fn_client_add_region(slot, &hs->region);
}


/*****************************************/
/* Handling SetColourMapEntries messages */
/*****************************************/

static void rf_host_colormap_hdr(void)
{
  CARD16 num_colors;

  log_write(LL_WARN, "Ignoring SetColourMapEntries message");

  num_colors = buf_get_CARD16(&cur_slot->readbuf[3]);
  if (num_colors > 0)
    aio_setread(rf_host_colormap_data, NULL, num_colors * 6);
  else
    aio_setread(rf_host_msg, NULL, 1);
}

static void rf_host_colormap_data(void)
{
  /* Nothing to do with colormap */
  aio_setread(rf_host_msg, NULL, 1);
}

/***********************************/
/* Handling ServerCutText messages */
/***********************************/

/* FIXME: Add state variables to the AIO_SLOT structure clone. */
static size_t cut_len;
static CARD8 *cut_text;

static void rf_host_cuttext_hdr(void)
{
  log_write(LL_DETAIL,
            "Receiving ServerCutText message from host, %lu byte(s)",
            (unsigned long)cut_len);

  cut_len = (size_t)buf_get_CARD32(&cur_slot->readbuf[3]);
  if (cut_len > 0)
    aio_setread(rf_host_cuttext_data, NULL, cut_len);
  else
    rf_host_cuttext_data();
}

static void rf_host_cuttext_data(void)
{
  cut_text = cur_slot->readbuf;
  aio_walk_slots(fn_host_pass_cuttext, TYPE_CL_SLOT);
  aio_setread(rf_host_msg, NULL, 1);
}

static void fn_host_pass_cuttext(AIO_SLOT *slot)
{
  fn_client_send_cuttext(slot, cut_text, cut_len);
}

/*************************************/
/* Functions called from client_io.c */
/*************************************/

/* FIXME: Function naming. Have to invent consistent naming rules. */

/*
 * Pass/forward the given message (ex: mouse/keyboard) to a VNC server/host.
 */
void pass_msg_to_master_host(CARD8 *msg, size_t len)
{
  AIO_SLOT *s;
  for (s = aio_first_slot(); s; s = s->next) {
    if (s->type == TYPE_HOST_ACTIVE_SLOT) {
      HOST_SLOT *hs = (HOST_SLOT *) s;
      /* send event to master host or all VNC SPUs if keyboard event */
      if (s == (AIO_SLOT *) s_master_host_slot ||
          (hs->is_vnc_spu && msg[0] == RFB_KEY_EVENT)) {
        AIO_SLOT *saved_slot = cur_slot;
        cur_slot = s;
        aio_write(NULL, msg, len);
        cur_slot = saved_slot;
      }
    }
  }
}


void pass_cuttext_to_master_host(CARD8 *text, size_t len)
{
  AIO_SLOT *saved_slot = cur_slot;
  CARD8 client_cuttext_hdr[8] = {
    6, 0, 0, 0, 0, 0, 0, 0
  };

  if (s_master_host_slot != NULL) {
    buf_put_CARD32(&client_cuttext_hdr[4], (CARD32)len);

    cur_slot = &s_master_host_slot->s;
    aio_write(NULL, client_cuttext_hdr, sizeof(client_cuttext_hdr));
    aio_write(NULL, text, len);
    cur_slot = saved_slot;
  }
}

/********************/
/* Helper functions */
/********************/

/*
 * Clear the framebuffer, invalidate hextile cache.
 */

static void reset_framebuffer(void)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  FB_RECT r;
  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);

  log_write(LL_DETAIL, "Clearing framebuffer and cache");

#if 0
  /* XXX only clear if _all_ servers go away */
  memset(g_framebuffer, 0, g_fb_width * g_fb_height * sizeof(CARD32));
#endif

  r.x = r.y = 0;
  r.w = g_fb_width;
  r.h = g_fb_height;

  invalidate_enc_cache(&r);

  /* Queue changed rectangle (the whole host screen) for each client */
  r.w = hs->fb_width;
  r.h = hs->fb_height;
  aio_walk_slots(fn_host_add_client_rect, TYPE_CL_SLOT);
}


/**
 * Send a FramebufferUpdateRequest for a particular rect to the
 * current host/server.
 */
void request_update_rect(HOST_SLOT *hs, int incr, int x, int y, int w, int h)
{
  unsigned char fbupdatereq_msg[10];

  assert(cur_slot->type == TYPE_HOST_ACTIVE_SLOT);
  assert(!hs->is_input_only);

  fbupdatereq_msg[0] = RFB_FRAMEBUFFER_UPDATE_REQUEST;
  fbupdatereq_msg[1] = (incr) ? 1 : 0;
  buf_put_CARD16(&fbupdatereq_msg[2], x);
  buf_put_CARD16(&fbupdatereq_msg[4], y);
  buf_put_CARD16(&fbupdatereq_msg[6], w);
  buf_put_CARD16(&fbupdatereq_msg[8], h);
  log_write(LL_DEBUG, "Sending FramebufferUpdateRequest message");
  aio_write(NULL, fbupdatereq_msg, sizeof(fbupdatereq_msg));

#ifdef NETLOGGER
  hs->serial_number++;
  if (hs->is_vnc_spu) {
    NL_info("vncproxy", "proxy.fbrequest.send",
            "NODE=s NUMBER=i", hs->s.name, hs->serial_number);
  }
#endif
}


/**
 * Send a FramebufferUpdateRequest (for the whole screen) to the
 * current host/server.
 */
static void request_update(int incr)
{
  HOST_SLOT *hs = (HOST_SLOT *)cur_slot;
  /*
  printf("Request update from %p VNC %d\n", (void*) hs, hs->is_vnc_spu);
  */
  request_update_rect(hs, incr, 0, 0, hs->fb_width, hs->fb_height);
}


static void fn_request_update(AIO_SLOT *slot)
{
  HOST_SLOT *hs = (HOST_SLOT *) slot;
  if (!hs->is_input_only && !hs->is_vnc_spu) {
    cur_slot = slot;
    request_update_rect(hs, /*incr*/0, 0, 0, hs->fb_width, hs->fb_height);
  }
}


void request_update_all(void)
{
  AIO_SLOT *save = cur_slot;
  aio_walk_slots(fn_request_update, TYPE_HOST_ACTIVE_SLOT);
  cur_slot = save;
}
