/* VNC Reflector
 * Copyright (C) 2001-2003 HorizonLive.com, Inc.  All rights reserved.
 *
 * This software is released under the terms specified in the file LICENSE,
 * included.  HorizonLive provides e-Learning and collaborative synchronous
 * presentation solutions in a totally Web-based environment.  For more
 * information about HorizonLive, please see our website at
 * http://www.horizonlive.com.
 *
 * This software was authored by Constantin Kaplinsky <const@ce.cctpu.edu.ru>
 * and sponsored by HorizonLive.com, Inc.
 *
 * $Id: rfblib.c,v 1.2 2006/11/02 19:36:07 alanh Exp $
 * RFB protocol helper functions
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>

#include "rfblib.h"
#include "d3des.h"

void buf_get_pixfmt(void *buf, RFB_PIXEL_FORMAT *format)
{
  CARD8 *bbuf = buf;

  memcpy(format, buf, SZ_RFB_PIXEL_FORMAT);
  format->r_max = buf_get_CARD16(&bbuf[4]);
  format->g_max = buf_get_CARD16(&bbuf[6]);
  format->b_max = buf_get_CARD16(&bbuf[8]);
}

void buf_put_pixfmt(void *buf, RFB_PIXEL_FORMAT *format)
{
  CARD8 *bbuf = buf;

  memcpy(buf, format, SZ_RFB_PIXEL_FORMAT);
  buf_put_CARD16(&bbuf[4], format->r_max);
  buf_put_CARD16(&bbuf[6], format->g_max);
  buf_put_CARD16(&bbuf[8], format->b_max);
}

void rfb_gen_challenge(CARD8 *buf)
{
  int i;

  srandom((unsigned int)time(NULL));
  for (i = 0; i < 16; i++)
    *buf++ = (unsigned char)random();
}

void rfb_crypt(CARD8 *dst_buf, const CARD8 *src_buf, const unsigned char *password)
{
  unsigned char key[8];

  memset(key, 0, 8);
  strncpy((char *)key, (char *)password, 8);
  deskey(key, EN0);
  des(src_buf, dst_buf);
  des(src_buf + 8, dst_buf + 8);
}

const char *rfb_encoding_name(int encoding)
{
   switch (encoding) {
   case RFB_ENCODING_RAW:
      return "RAW";
   case RFB_ENCODING_COPYRECT:
      return "COPYRECT";
   case RFB_ENCODING_RRE:
      return "RRE";
   case RFB_ENCODING_CORRE:
      return "CORRE";
   case RFB_ENCODING_HEXTILE:
      return "HEXTILE";
   case RFB_ENCODING_ZLIB:
      return "ZLIB";
   case RFB_ENCODING_TIGHT:
      return "TIGHT";
   case RFB_ENCODING_ZLIBHEX:
      return "ZLIBHEX";
   case RFB_ENCODING_ZRLE:
      return "ZRLE";
   case RFB_ENCODING_COMPRESSLEVEL0:
      return "COMPRESSLEVEL0";
   case RFB_ENCODING_COMPRESSLEVEL9:
      return "COMPRESSLEVEL9";
   case RFB_ENCODING_XCURSOR:
      return "XCURSOR";
   case RFB_ENCODING_RICH_CURSOR:
      return "RICH_CURSOR";
   case RFB_ENCODING_POINTER_POS:
      return "POINTER_POS";
   case RFB_ENCODING_RAW24:
      return "RAW24";
   case RFB_ENCODING_FRAME_SYNC:
      return "FRAME_SYNC";
   case RFB_ENCODING_CHROMIUM:
      return "CHROMIUM";
   case RFB_ENCODING_CHROMIUM2:
      return "CHROMIUM2";
   case RFB_ENCODING_QUALITYLEVEL0:
      return "QUALITYLEVEL0";
   case RFB_ENCODING_QUALITYLEVEL9:
      return "QUALITYLEVEL9";
   case RFB_ENCODING_LASTRECT:
      return "LASTRECT";
   case RFB_ENCODING_NEWFBSIZE:
      return "NEWFBSIZE";
   default:
      return "unknown";
   }
}
